-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-11-2024 a las 02:06:43
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `farmanada`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE `compra` (
  `id_compra` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `subtotal` double NOT NULL,
  `iva` double NOT NULL,
  `total` double NOT NULL,
  `fo_producto` int(11) NOT NULL,
  `fo_pago` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `fo_pedido` int(11) NOT NULL,
  `pagada` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`id_factura`, `fecha`, `fo_pedido`, `pagada`) VALUES
(1, '2023-07-23', 1, 1),
(2, '2021-11-15', 2, 1),
(3, '2024-03-10', 3, 1),
(4, '2022-08-05', 4, 0),
(5, '2020-12-25', 5, 1),
(6, '2025-01-01', 6, 1),
(7, '2023-06-18', 7, 1),
(8, '2024-09-30', 8, 0),
(9, '2020-03-14', 9, 1),
(10, '2025-04-27', 10, 1),
(11, '2022-02-20', 11, 1),
(12, '2021-10-12', 12, 0),
(13, '2023-05-19', 13, 1),
(14, '2024-07-08', 14, 1),
(15, '2020-09-22', 15, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--

CREATE TABLE `marca` (
  `id_marca` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `fo_proovedor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`id_marca`, `nombre`, `fo_proovedor`) VALUES
(1, 'PharmaPlus', 1),
(2, 'SaludVital', 3),
(3, 'BioMedic', 5),
(4, 'VitalCare', 7),
(5, 'MediTrust', 9),
(6, 'NutriPharm', 1),
(7, 'HealthLife', 3),
(8, 'CuraMed', 5),
(9, 'WellnessLab', 7),
(10, 'GenPharma', 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `metodop`
--

CREATE TABLE `metodop` (
  `id_pago` int(11) NOT NULL,
  `selecccion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `metodop`
--

INSERT INTO `metodop` (`id_pago`, `selecccion`) VALUES
(2, 'Tarjeta'),
(3, 'Efectivo'),
(4, 'Contraentrega/Domici'),
(5, 'Regalo'),
(6, 'Ninguna');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedido`
--

CREATE TABLE `pedido` (
  `id_pedido` int(11) NOT NULL,
  `unidades` int(11) NOT NULL,
  `subtotal` double NOT NULL,
  `iva` double NOT NULL,
  `total` double NOT NULL,
  `fo_producto` int(11) NOT NULL,
  `fo_pago` int(11) NOT NULL,
  `fo_cliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pedido`
--

INSERT INTO `pedido` (`id_pedido`, `unidades`, `subtotal`, `iva`, `total`, `fo_producto`, `fo_pago`, `fo_cliente`) VALUES
(1, 3, 16500, 3135, 19635, 1, 2, 2),
(2, 5, 42500, 8075, 50575, 3, 4, 4),
(3, 2, 37000, 7030, 44030, 5, 3, 6),
(4, 4, 128000, 24320, 152320, 7, 6, 8),
(5, 6, 108000, 20520, 128520, 9, 5, 10),
(6, 1, 14000, 2660, 16660, 11, 3, 2),
(7, 3, 22500, 4275, 26775, 13, 4, 4),
(8, 4, 100000, 19000, 119000, 15, 6, 6),
(9, 2, 24000, 4560, 28560, 17, 2, 8),
(10, 5, 47500, 9025, 56525, 19, 2, 10),
(11, 7, 24500, 4655, 29155, 21, 5, 2),
(12, 2, 22000, 4180, 26180, 23, 6, 4),
(13, 6, 102000, 19380, 121380, 25, 3, 6),
(14, 4, 22000, 4180, 26180, 27, 5, 8),
(15, 3, 22500, 4275, 26775, 29, 4, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `codigo` varchar(15) DEFAULT NULL,
  `precio_unitario` int(15) NOT NULL,
  `stock` int(15) NOT NULL,
  `lote` varchar(30) DEFAULT NULL,
  `fo_marca` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id_producto`, `nombre`, `codigo`, `precio_unitario`, `stock`, `lote`, `fo_marca`) VALUES
(1, 'Bebida Té Fizzy 1.5L', 'A1B2C3D4', 5500, 120, 'LOT2024A', 2),
(2, 'Agua Miscelar 475ml', 'X9Y8Z7W6', 15000, 80, 'LOT2024B', 4),
(3, 'Gel antibacterial 100ml', 'P8Q7R6S5', 8500, 200, 'LOT2024C', 6),
(4, 'Pastillas DigestEase 24u', 'M1N2O3P4', 12500, 50, 'LOT2024D', 8),
(5, 'Jarabe TosFree 120ml', 'T4U3V2W1', 18500, 30, 'LOT2024E', 10),
(6, 'Jabón Neutro DermaCare', 'K5L6M7N8', 5500, 150, 'LOT2024F', 2),
(7, 'Protector Solar SPF50 200ml', 'R9S8T7U6', 32000, 60, 'LOT2024G', 4),
(8, 'Shampoo Anti-Caída 400ml', 'H1I2J3K4', 22500, 100, 'LOT2024H', 6),
(9, 'Vitaminas Complejo B 30u', 'V8W7X6Y5', 18000, 90, 'LOT2024I', 8),
(10, 'Suero Rehidratante 500ml', 'E3F4G5H6', 2500, 300, 'LOT2024J', 10),
(11, 'Enjuague Bucal FreshMint 500ml', 'Q5R6S7T8', 14000, 70, 'LOT2024K', 2),
(12, 'Crema Corporal Hidratante 250ml', 'U9V8W7X6', 28000, 50, 'LOT2024L', 4),
(13, 'Tiritas Adhesivas 50u', 'L1M2N3O4', 7500, 250, 'LOT2024M', 6),
(14, 'Esparadrapo Adhesivo 3m', 'F8G7H6I5', 6000, 180, 'LOT2024N', 8),
(15, 'Termómetro Digital', 'Y3Z4A5B6', 25000, 40, 'LOT2024O', 10),
(16, 'Aceite Esencial Relax 30ml', 'I5J6K7L8', 20000, 60, 'LOT2024P', 2),
(17, 'Desodorante Roll-On 50ml', 'Z9A8B7C6', 12000, 150, 'LOT2024Q', 4),
(18, 'Almohadilla Térmica', 'G1H2I3J4', 45000, 25, 'LOT2024R', 6),
(19, 'Cereal NutriFit 300g', 'X8Y7Z6A5', 9500, 130, 'LOT2024S', 8),
(20, 'Jarabe Multivitamínico 200ml', 'B3C4D5E6', 22000, 40, 'LOT2024T', 10),
(21, 'Paquete de Algodón 50g', 'M5N6O7P8', 3500, 300, 'LOT2024U', 2),
(22, 'Toallitas Húmedas 30u', 'O9P8Q7R6', 8000, 180, 'LOT2024V', 4),
(23, 'Pasta Dental MaxClean 120g', 'K1L2M3N4', 11000, 200, 'LOT2024W', 6),
(24, 'Guantes Desechables 100u', 'W8X7Y6Z5', 24000, 150, 'LOT2024X', 8),
(25, 'Mascarilla Facial Detox', 'D3E4F5G6', 17000, 80, 'LOT2024Y', 10),
(26, 'Toallas Sanitarias 10u', 'J5K6L7M8', 7000, 200, 'LOT2024Z', 2),
(27, 'Panela Pulverizada 500g', 'A9B8C7D6', 5500, 300, 'LOT2024AA', 4),
(28, 'Miel Pura 350g', 'T1U2V3W4', 18500, 70, 'LOT2024AB', 6),
(29, 'Bebida Energizante 250ml', 'R8S7T6U5', 7500, 100, 'LOT2024AC', 8),
(30, 'Alcohol Antiséptico 70% 500ml', 'F3G4H5I6', 4500, 250, 'LOT2024AD', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo`
--

CREATE TABLE `tipo` (
  `id_tipo` int(11) NOT NULL,
  `rol` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipo`
--

INSERT INTO `tipo` (`id_tipo`, `rol`) VALUES
(1, 'Proovedor'),
(2, 'Cliente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ubicacion`
--

CREATE TABLE `ubicacion` (
  `id_ubicacion` int(11) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `departamento` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ubicacion`
--

INSERT INTO `ubicacion` (`id_ubicacion`, `municipio`, `departamento`) VALUES
(1, 'Pereira', 'Risaralda'),
(2, 'Medellin', 'Antioquia'),
(3, 'Tunja', 'Boyacá'),
(4, 'Bogotá', 'Cundinamarca'),
(5, 'Neiva', 'Huila'),
(6, 'Cali', 'Valle del Cauca'),
(7, 'Ibagué', 'Tolima'),
(8, 'Sincelejo', 'Sucre'),
(9, 'Bucaramanga', 'Santander'),
(10, 'Armenia', 'Quindio');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuarios` int(11) NOT NULL,
  `identificacion` int(15) NOT NULL,
  `nombre` varchar(80) DEFAULT NULL,
  `direccion` varchar(80) DEFAULT NULL,
  `celular` varchar(20) DEFAULT NULL,
  `correo` varchar(50) DEFAULT NULL,
  `fechan` date NOT NULL,
  `fo_ubicacion` int(11) NOT NULL,
  `fo_tipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuarios`, `identificacion`, `nombre`, `direccion`, `celular`, `correo`, `fechan`, `fo_ubicacion`, `fo_tipo`) VALUES
(1, 1957238462, 'Carlos Gómez', 'Calle 23', '3141234567', 'carlos.gomez@example.com', '1985-04-17', 5, 1),
(2, 1836514790, 'Lucía Pérez', 'Avenida 11', '3107894561', 'lucia.perez@example.com', '1990-08-29', 8, 2),
(3, 1293841654, 'Miguel Ríos', 'Calle 4', '3174567890', 'miguel.rios@example.com', '1975-02-15', 3, 1),
(4, 1468392057, 'Ana Martínez', 'Carrera 10', '3123456789', 'ana.martinez@example.com', '2002-05-24', 7, 2),
(5, 1840275691, 'David Rodríguez', 'Calle 6', '3156789453', 'david.rodriguez@example.com', '1988-09-12', 1, 1),
(6, 1271368490, 'María López', 'Avenida 8', '3139123456', 'maria.lopez@example.com', '1995-12-03', 9, 2),
(7, 1391025476, 'Fernando Jiménez', 'Carrera 2', '3198765432', 'fernando.jimenez@example.com', '1978-03-10', 4, 1),
(8, 1920481375, 'Diana Castro', 'Calle 9', '3101234567', 'diana.castro@example.com', '1992-11-20', 6, 2),
(9, 1819352670, 'Sofía Romero', 'Calle 12', '1174561230', 'sofia.romero@example.com', '2000-06-30', 2, 1),
(10, 1539241860, 'Juan Ortiz', 'Avenida 15', '3146789123', 'juan.ortiz@example.com', '1983-01-25', 10, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`id_compra`),
  ADD KEY `fo_pago` (`fo_pago`),
  ADD KEY `fo_producto` (`fo_producto`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`id_factura`),
  ADD KEY `fo_pedido` (`fo_pedido`);

--
-- Indices de la tabla `marca`
--
ALTER TABLE `marca`
  ADD PRIMARY KEY (`id_marca`),
  ADD KEY `fo_proovedor` (`fo_proovedor`);

--
-- Indices de la tabla `metodop`
--
ALTER TABLE `metodop`
  ADD PRIMARY KEY (`id_pago`);

--
-- Indices de la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `fo_producto` (`fo_producto`),
  ADD KEY `fo_pago` (`fo_pago`),
  ADD KEY `fo_cliente` (`fo_cliente`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id_producto`),
  ADD KEY `fo_marca` (`fo_marca`);

--
-- Indices de la tabla `tipo`
--
ALTER TABLE `tipo`
  ADD PRIMARY KEY (`id_tipo`);

--
-- Indices de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  ADD PRIMARY KEY (`id_ubicacion`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuarios`),
  ADD KEY `fo_tipo` (`fo_tipo`),
  ADD KEY `fo_ciudad` (`fo_ubicacion`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `compra`
--
ALTER TABLE `compra`
  MODIFY `id_compra` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `id_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `marca`
--
ALTER TABLE `marca`
  MODIFY `id_marca` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `metodop`
--
ALTER TABLE `metodop`
  MODIFY `id_pago` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `pedido`
--
ALTER TABLE `pedido`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `tipo`
--
ALTER TABLE `tipo`
  MODIFY `id_tipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `ubicacion`
--
ALTER TABLE `ubicacion`
  MODIFY `id_ubicacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuarios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `compra_ibfk_1` FOREIGN KEY (`fo_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `compra_ibfk_2` FOREIGN KEY (`fo_pago`) REFERENCES `metodop` (`id_pago`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`fo_pedido`) REFERENCES `pedido` (`id_pedido`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `marca`
--
ALTER TABLE `marca`
  ADD CONSTRAINT `marca_ibfk_1` FOREIGN KEY (`fo_proovedor`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `pedido_ibfk_1` FOREIGN KEY (`fo_cliente`) REFERENCES `usuarios` (`id_usuarios`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `pedido_ibfk_2` FOREIGN KEY (`fo_pago`) REFERENCES `metodop` (`id_pago`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `pedido_ibfk_3` FOREIGN KEY (`fo_producto`) REFERENCES `producto` (`id_producto`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`fo_marca`) REFERENCES `marca` (`id_marca`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`fo_ubicacion`) REFERENCES `ubicacion` (`id_ubicacion`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`fo_tipo`) REFERENCES `tipo` (`id_tipo`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

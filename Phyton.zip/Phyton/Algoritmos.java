
package algoritmos;

import java.util.Scanner;
import java.util.Arrays;

public class Algoritmos {
    public static void main(String[] args){
        
        Scanner entradas = new Scanner(System.in);
       
        System.out.print("¿Cuantos elementos desea procesar? ");
        int nroElementos = entradas.nextInt();
        
        int[] numeros = new int[nroElementos];
       
        int i = 0;
        while(i>=0 && i<=numeros.length){
            System.out.print("Ingresa el valor de la posicion " + i + ": ");
            numeros[i] = entradas.nextInt();
            
            
            i++;
        
        }
        
        for (i = 0; i < numeros.length; i++){
            System.out.println("El valor de la posicion " + i + " es: " + numeros[i]);
          
        
        }
    }        

}

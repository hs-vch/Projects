Algoritmo Ciclo_SI
	Definir n1 Como Entero
	Escribir ' '
	Escribir 'Ingrese un n�mero entero'
	Leer n1
	//n1 <- 10
	Escribir ' '
	SI n1>=1 y n1<=10 Entonces
		Escribir "El n�mero est� entre 1 y 10"
	SiNo
		SI n1<=0 Entonces
			Escribir "El n�mero es cero o negativo"
		SiNo 
			Escribir "El n�mero es mayor a 10"
		FinSi
	FinSi
FinAlgoritmo

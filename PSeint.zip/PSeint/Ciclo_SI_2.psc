Algoritmo 	Ciclo_SI_Ejercicio
	Escribir 'Buenos d�as alegria.'
	Escribir ' '
	Escribir 'Ingrese un n�mero entre 1 y 15'
	Leer n1
	n2 <- 1
	Escribir ' ' 
	Si n2<=n1 Entonces
		res<- res+n2
		n2 <- n2+1
		Si n2<=n1 Entonces
			res<- res+n2
			n2 <- n2+1
			Si n2<=n1 Entonces
				res<- res+n2
				n2 <- n2+1
				Si n2<=n1 Entonces
					res<- res+n2
					n2 <- n2+1
					Si n2<=n1 Entonces
						res<- res+n2
						n2 <- n2+1
						Si n2<=n1 Entonces
							res<- res+n2
							n2 <- n2+1
							Si n2<=n1 Entonces
								res<- res+n2
								n2 <- n2+1
								Si n2<=n1 Entonces
									res<- res+n2
									n2 <- n2+1
									Si n2<=n1 Entonces
										res<- res+n2
										n2 <- n2+1
										Si n2<=n1 Entonces
											res<- res+n2
											n2 <- n2+1
											Si n2<=n1 Entonces
												res<- res+n2
												n2 <- n2+1
												Si n2<=n1 Entonces
													res<- res+n2
													n2 <- n2+1
													Si n2<=n1 Entonces
														res<- res+n2
														n2 <- n2+1
														Si n2<=n1 Entonces
															res<- res+n2
															n2 <- n2+1
															Si n2<=n1 Entonces
																res<- res+n2
																n2 <- n2+1
															FinSi
														FinSi
													FinSi
												FinSi
											FinSi
										FinSi
									FinSi
								FinSi
							FinSi
						FinSi
					FinSi
				FinSi
			FinSi
		FinSi
	FinSi
	Escribir 'Su resultado va en ' res
FinAlgoritmo

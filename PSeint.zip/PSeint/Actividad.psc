Algoritmo sin_titulo
	Definir n1, n2 Como Entero
	Escribir " " 
	Escribir "Hola, soy tu asistente de suma"
	Escribir ' '
	Escribir "Ingrese un n�mero de 1 digito"
	Leer n1
	Escribir "Ingrese un n�mero de 2 digitos"
	Leer n2
	res<- n1 + n2
	Escribir "El resultado de la suma de dos n�meros es:" res
FinAlgoritmo

Algoritmo Ciclo_SI
	Definir n1, n2 como Entero
	Escribir 'Bienvenido al Ciclo SI'
	Escribir ' '
	Escribir 'Digite el primer n�mero: '
	Leer n1
	Si n1>=10 Entonces 
		Escribir 'Su primer digito es un n�mero de dos digitos mayor a 9'
	Sino
		Escribir 'Su primer digito es un n�mero de un digito menor a 10'
	FinSi
	Escribir ' '
	Escribir 'Digite el segundo n�mero: '
	Leer n2
	Si n2>=10 Entonces
		Escribir 'Su segundo digito es un n�mero de dos digitos mayor a 9'
	Sino
		Escribir 'Su segundo digito es un n�mero de un digito menor a 10'
	FinSi
	Escribir ' '
	res <- n1 + n2 
	Si res>=10 Entonces
		Escribir 'Su resultado es un n�mero de dos digitos mayor a 9: ' res
	SiNo
		Escribir 'Su resultado es un n�mero de un digito menor a 10: ' res
	FinSi
FinAlgoritmo

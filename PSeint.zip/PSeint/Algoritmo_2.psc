Algoritmo Ejemplo_2
	Definir n1, n2, n3 como Real
	Escribir ' '
	Escribir 'Hola mundo, soy yo, el segundo algoritmo!'
	Escribir ' '
	Escribir 'Escriba el primer n�mero'
	Leer n1 
	Escribir 'Escriba el segundo n�mero'
	Leer n2
	Escribir 'Escriba el tercer n�mero'
	Leer n3
	res<- n1 + n2 + n3
	Escribir 'Su resultado es: ' res
	Escribir ' '
	Escribir 'Gracias por su atenci�n'
FinAlgoritmo

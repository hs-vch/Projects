function menu(dato){
    switch(dato){
        case 1:
            document.getElementById('enun1').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 2:
            document.getElementById('enun2').style.display = 'block';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 3:
            document.getElementById('enun3').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 4:
            document.getElementById('enun4').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 5:
            document.getElementById('enun5').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 6:
            document.getElementById('enun6').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        case 7:
            document.getElementById('enun7').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
        break;
    }
}


function ejer1(){
    var mensaje, largo;
    var arr = [5, 10, 15, 20, 25];
    
    largo = arr.length;
    mensaje = " ";

    for(con=0; con < largo; con++){
        mensaje += arr[con] + " posición " + con + "<br><br>";
    }

    media = 
    
    document.getElementById('resul').innerHTML = mensaje;

}

function ejer2(){
    var mensaje, largo, media, suma;
    var arr = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19];

    largo = arr.length; 
    mensaje = " ";
    var suma = 0;

    for(var con = 0; con < largo; con++){
        mensaje += arr[con] + " posición " + con + "<br>";
        suma += arr[con];
    }
    
    var media = suma / largo;

    mensaje += "<br><br> La media del arreglo es " + media;  

    document.getElementById('resul').innerHTML = mensaje;


}

function ejer3(){
    var tamaño = Number(document.getElementById('largo').value);
    var multiplos = Number(document.getElementById('numero').value);
    var mensaje, con;

    for(con = 0; con <= tamaño; con+=multiplos){

    }
}



document.getElementById('enunciado').innerHTML = '<p> Diseñe el algoritmo (en pseudocódigo) de un programa que:  Pida por teclado el radio (dato real) de una esfera.  En el caso de que el radio sea menor o igual que 0, muestre por pantalla el mensaje: ERROR: El radio debe ser mayor que cero.".  Muestre por pantalla: "El área de una esfera de radio es: <área>".  Nota 1: Área de una esfera = 4 * pi * radio2</p>';
 
const radio = Number(prompt("Escriba el radio de una esfera"));
let area = 4 * Math.PI *radio ** 2;

if(radio <= 0){
    alert(ERROR);
}else{
    mensaje = "El área de una esfera de radio " + radio + " es " + area;
}

document.getElementById('resultado').innerHTML = mensaje;
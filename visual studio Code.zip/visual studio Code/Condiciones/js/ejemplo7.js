//El if puede tener 2 o más condiciones.
document.getElementById('enunciado').innerHTML = '<p>Un cliente compra productos, si lleva como producto zapatos y lleva más de 5 pares, tendrá un descuento del 15%, teniendo en cuenta que cada par vale 80.000 y a los demás productos se les debe pedir el precio</p>';

var producto, p_producto, cantidad, subtotal, p_desc, total;
const l_zap = 5;
const desc = 0.15;
const p_zap = 80000;

producto = prompt("Ingresar nombre del producto");
cantidad = prompt("¿Cuantos va a llevar?");

if(producto == "zapatos" && cantidad > l_zap){
    subtotal = cantidad * p_zap;
    p_desc = subtotal * desc;
}else if(producto == "zapatos"){
    subtotal = cantidad * p_zap;
    descuento = 0;
}else{
    precio =Number(prompt("Ingresar precio del producto"));
    subtotal = precio * cantidad;
    descuento = 0;
}

total = subtotal - p_desc
mensaje = "La cantidad de " + producto + " a llevar es " + cantidad;
mensaje += "<br>El subtotal es $" + subtotal;
mensaje += "<br>El descuento es $" + p_desc;
mensaje += "<br>El total es $" + total;

document.getElementById('resultado').innerHTML = mensaje;
document.getElementById('enunciado').innerHTML = '<p>Imprimir el nombre de un articulo, clave, precio original y su precio con descuento. El descuento lo hace en base a la clave, Si la clave es 01 el descuento es del 10% y si la clave es 02 el descuento es del 20% (sólo existen dos claves)</p>';

var nombre_art, precio_or, descuento, precio_desc, clave;
const clave01 = 0.1;
const clave02 = 0.2;

nombre_art = prompt("Ingrese el nombre del articulo");
precio_or = Number(prompt("Ingrese el precio original del articulo"));
clave = Number(prompt("Ingrese una clave, 01 o 02"));

if(clave==01){
    descuento = precio_or * clave01;
}else if(clave==02){
    descuento = precio_or * clave02;
}else{
    alert("La clave no es correcta");
    desc = 0;
}

precio_desc = precio_or - descuento

mensaje = nombre_art + " tiene un precio de $" + precio_or;
mensaje += "<br>La clave de " + nombre_art + " es " + clave;
mensaje += "<br>El precio con descuento es de $" + precio_desc;

document.getElementById('resultado').innerHTML = mensaje;
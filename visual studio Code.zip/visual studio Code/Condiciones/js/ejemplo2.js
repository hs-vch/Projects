//If en cascada
document.getElementById('enunciado').innerHTML = '<p>Capturar el nombre de una persona que quiere jugar voleibol, tambien capturar su edad, si la persona tiene 18 o mas anos puede jugar en la seleccion de mayores, de lo contrario en la seleccion de menores</p>';

var nombre, edad, mensaje; 

nombre = prompt("Ingrese nombre de la persona");
edad = Number(prompt("Ingrese la edad de la persona"));

if(edad >= 18){
    mensaje = "La persona con nombre " + nombre + " puede jugar en la selección de mayores por tener una edad de " + edad;
}else{
    mensaje = "La persona con nombre " + nombre + " puede jugar en la selección de menores por tener una edad de " + edad;
}

document.getElementById('resultado').innerHTML = mensaje;
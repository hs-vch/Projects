document.getElementById('enunciado').innerHTML = '<p>Un paquete de galletas cuesta $3.500 y contiene 15 galletas, cuánto cuestan 4 de ellas? Elabore un algoritmo para obtener la respuesta.</p>';
 
const n_galletas = Number(prompt("Digite un número de galletas"));
const p_galletas = 3500;
const galletas = 15;
let v_galleta = p_galletas* n_galletas/galletas;
let v_g = parseInt(v_galleta);

mensaje = n_galletas + " galletas cuestan " + v_g;

document.getElementById('resultado').innerHTML = mensaje;
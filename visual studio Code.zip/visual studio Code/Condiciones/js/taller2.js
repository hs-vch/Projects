document.getElementById('enunciado').innerHTML = '<p>Hacer un algoritmo que calcule el total a pagar por la compra de camisas. Si se compran tres camisas o más se aplica un descuento del 20% sobre el total de la compra y si son menos de tres camisas un descuento del 10%.</p>';

var precio, total, subtotal, n_camisas, descuento;
const producto = " camisas";
const desc1 = 0.1;
const desc2 = 0.2;

precio = Number(promp("Digite el precio de" + producto));
n_camisas = Number(prompt("Digite el número de" + producto + " a llevar"));

subtotal = precio * n_camisas;

if(n_camisas >= 3){
    descuento = subtotal * desc2;
}else{
    descuento = subtotal * desc1;
}

total = subtotal - descuento;

mensaje = "El total a pagar por la compra de " + n_camisas + producto +" es de $" + total;

document.getElementById('resultado').innerHTML = mensaje;
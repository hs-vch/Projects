document.getElementById('enunciado').innerHTML = '<p>Un cliente va a comprar camisas, cada camisa cuesta 50.000 pesos, si el cliente lleva más de 5 camisas se le dará un descuento del 15%, mostrar en pantalla cuantas camisas va a llevar, cuanto seria el subtotal, cuanto seria el descuento y el total.</p>';

var cantidad, subtotal, descuento, total, mensaje;
const producto = "camisas";
const precio = 50000;
const p_desc = 0.15;

cantidad = Number(prompt("Cuantas " + producto + " va a llevar"));

subtotal = precio * cantidad; 

if(cantidad > 5){
    descuento = subtotal * p_desc;
}else{
    descuento = 0
}

total = subtotal - descuento;

mensaje = "La cantidad de " + producto + " a llevar es " + cantidad;
mensaje += "<br>El subtotal es $" + subtotal;
mensaje += "<br>El descuento es $" + descuento;
mensaje += "<br>El total es $" + total

document.getElementById('resultado').innerHTML = mensaje;
//El if puede tener 2 o más condiciones.
document.getElementById('enunciado').innerHTML = '<p>Capturar nombre de una persona, edad, peso y estatura. Si la persona tiene más o igual a 18 años puede jugar en las ligas mayores, pero solo podra jugar si tiene una estatura mayor o igual a 1.75 y un peso menor a 85. Si tiene menos de 18, puede jugar en ligas menores.</p>';

var edad, nombre, peso, estatura;
const L_edad = 18;
const L_estatura = 1.75;
const L_peso = 85;

nombre = prompt("Ingresar nombre");
edad = Number(prompt("Ingresar edad"));
peso = Number(prompt("Ingresar peso"));
estatura = Number(prompt("Ingresar estatura"));

if(estatura >= L_estatura && peso < L_peso){
    if(edad >=L_edad){
        mensaje = " Puede jugar en mayores";
    }else{
        mensaje = "Puede jugar en menores";
    }
}else{
    mensaje = "No puede jugar";
}


document.getElementById('resultado').innerHTML = mensaje;
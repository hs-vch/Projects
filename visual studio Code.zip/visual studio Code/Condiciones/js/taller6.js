document.getElementById('enunciado').innerHTML = '<p>Hacer un algoritmo que permita pasar de kilogramos a gramos y toneladas.</p>';
 
var convertir, resultado;
const kilogramos = Number(prompt("Escriba un número de kilogramos"));
const gramos = kilogramos * 1000;
const toneladas = kilogramos / 1000;

convertir = prompt("Escriba si quiere convertir a gramos o toneladas");

if(convertir == "gramos"){
    resultado = gramos;
}else if(convertir == "toneladas"){
    resultado = toneladas;
}else{
    resultado = "Medida incorrecta.";
}

mensaje = kilogramos + "kg a " + convertir + " es igual a = " + resultado;

document.getElementById('resultado').innerHTML = mensaje;
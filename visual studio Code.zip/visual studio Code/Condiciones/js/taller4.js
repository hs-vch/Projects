document.getElementById('enunciado').innerHTML = '<p>Calcular el número de pulsaciones que debe tener una persona por cada 10 segundos de ejercicio aeróbico; la fórmula que se aplica cuando el sexo es femenino es:  num. pulsaciones ← (220 - edad)/10 y si el sexo es masculino:  num. pulsaciones ← (210 - edad)/10</p>';
 
var edad, sexo, nombre, n_pulsasiones; 
const M = "masculino";
const F = "femenino";
const segundos = 10;

nombre = prompt("Escriba su nombre");
sexo = prompt("Escriba M si su sexo es masculino - F si es femenino");
edad = Number(prompt("Escriba su edad"));

if(sexo == "masculino"){
    n_pulsasiones = (210 - edad)/segundos;
}else if(sexo == "femenino"){
    n_pulsasiones = (210 - edad)/segundos;
}else{
    alert("el sexo no es correcto");
    n_pulsasiones = 0
}

mensaje = "El numero de pulsasiones que debe tener " + nombre + " es de " + n_pulsasiones;

document.getElementById('resultado').innerHTML = mensaje;
document.getElementById('enunciado').innerHTML = '<p>En un supermercado se hace una promoción, mediante la cual el cliente obtiene un descuento dependiendo de un número que se escoge al azar. Si el número escogido es menor que 74 el descuento es del 15% sobre el total de la compra, si es mayor o igual a 74 el descuento es del 20%. Obtener cuánto dinero se le descuenta.</p>';
 
var n_azar, total_c, total_desc, descuento;
const n_l = 74;
const des1 = 0.15;
const desc2 = 0.2;

n_azar = Number(prompt("Digite un número"));
total_c = Number(prompt("Digite el total de la compra"));

if(n_azar < n_l){
    descuento = total_c * des1;
}else if(n_azar >= n_l){
    descuento = total_c * desc2;
}else{
    descuento = 0;
}

total_desc = total_c - descuento;

mensaje = "El total inicial de su compra es $" + total_c
mensaje += "<br> El total de la compra con descuento es $" + total_desc
mensaje += "<br> El dinero descontado es $" +descuento

document.getElementById('resultado').innerHTML = mensaje;
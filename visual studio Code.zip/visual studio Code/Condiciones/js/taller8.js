document.getElementById('enunciado').innerHTML = '<p>Si 15 cuadernos cuestan $75000, cuánto cuestan 135 cuadernos?. Elabore un algoritmo para hallar la respuesta correcta.</p>';
 
const n_cuadernos = Number(prompt("Digite un número de cuadernos"));
const p_cuadernos = 75000;
const cuadernos = 15;
let v_cuadernos = p_cuadernos* n_cuadernos/cuadernos;
let v_c = parseInt(v_cuadernos);

mensaje = n_cuadernos + " cuadernos cuestan " + v_c;

document.getElementById('resultado').innerHTML = mensaje;
document.getElementById('enunciado').innerHTML = '<p>Elabore un algoritmo que lea un número negativo e imprima el número y el positivo del mismo.</p>';
 
 var numero_n, numero_p, numero;

numero_n = parseInt(prompt("Ingrese un número negativo"));

if(numero_n > 0){
    numero_n = numero_n * -1
}else{
    numero_n = numero_n
}

numero_p = numero_n * -1 



mensaje = "El numero entero negativo " + numero_n + " y en positivo " + numero_p;

document.getElementById('resultado').innerHTML = mensaje;
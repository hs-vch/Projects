//El if puede tener 2 o más condiciones.
document.getElementById('enunciado').innerHTML = '<p>Pedir el salario de un empleado, si el salario es menos o igual a 2400000, dar un subsidio de 200000, siempre y cuando tenga en el mes 160 horas trabajadas. Mostrar el salario neto.</p>';

var salario, h_t, salario_neto;
const l_Salario = 2400000;
const l_h_t = 160;
const subsidio = 200000;

salario = Number(prompt("Ingrese su salario"));
h_t = Number(prompt("Ingrese cantidad de horas trabajadas"));

if(salario <= l_Salario && h_t == l_h_t){
    salario_neto = salario + subsidio;
}else{
    salario_neto = salario;
}

mensaje = "Su salario neto es " + salario_neto;

document.getElementById('resultado').innerHTML = mensaje;
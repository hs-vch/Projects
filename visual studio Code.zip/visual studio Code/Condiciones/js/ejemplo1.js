//IF - SI
document.getElementById('enunciado').innerHTML = '<p>Capturar dos números e indicar cual número es mayor</p>';

var n1, n2, mensaje;

n1 = Number(prompt("Ingrese primer número"));
n2 = Number(prompt("Ingrese segundo número"));

if(n1 > n2){
    mensaje = "n1 = " + n1 + " es mayor que n2 = " + n2;
}else{
    mensaje = "n2 = " + n2 + " es mayor que n1 = " + n1;

}

document.getElementById('resultado').innerHTML = mensaje;
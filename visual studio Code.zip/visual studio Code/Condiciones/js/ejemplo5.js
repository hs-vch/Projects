//SI PUEDE ESTAR DENTRO DE OTRO SI - SI ANIDADOS
document.getElementById('enunciado').innerHTML = '<p>Capturar la fecha de nacimiento de una persona y calcular su edad</p>';

var day, month, years, edad, mensaje;
fa = new Date();
const diaa = fa.getDate();
const mesa= fa.getMonth()+1;
const yeara = fa.getFullYear();

dian = Number(prompt("Ingrese día de nacimiento"));
mesn = Number(prompt("Ingrese mes de nacimiento"));
earn = Number(prompt("Ingrese año de nacimiento"));

if(mesn < mesa){
    edad = yeara - earn;
}else if(mesn > mesa){
    edad = yeara - earn - 1;
}else if(dian < diaa){
    edad = yeara - earn;
}else if(dian > diaa){
    edad = yeara - earn - 1;
}else{
    alert("Esta cumpliendo años");
    edad = yeara - earn;
}

mensaje = "La persona tiene una edad de " + edad;

document.getElementById('resultado').innerHTML = mensaje;
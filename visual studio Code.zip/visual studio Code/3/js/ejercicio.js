function validar_final_1(){
    var nombre = document.getElementById('nombre').value;
    var marca = document.getElementById('marca').value;
    var precioc = document.getElementById('precioc').value;
    var stock = document.getElementById('stock').value;
    
    if(nombre == ""){
        document.getElementById('error1').style.display = 'block';
    }else{
        document.getElementById('error1').style.display = 'none';
    }
    
    if(marca == ""){
        document.getElementById('error2').style.display = 'block';
    }else{
        document.getElementById('error2').style.display = 'none';
    }
    
    
    if(precioc == ""){
        document.getElementById('error3').style.display = 'block';
    }else{
        document.getElementById('error3').style.display = 'none';
    }
    
    
    if(stock == ""){
        document.getElementById('error4').style.display = 'block';
    }else{
        document.getElementById('error4').style.display = 'none';
    }
}

function validar_final_2(){
    var nombrev = document.getElementById('nombrev').value;
    var cedula = document.getElementById('cedula').value;
    var email = document.getElementById('email').value;
    var telefono = document.getElementById('telefono').value;
        
    if(nombrev == ""){  
        document.getElementById('error5').style.display = 'block';
    }else{
        document.getElementById('error5').style.display = 'none';
    }
        
    if(cedula == ""){
        document.getElementById('error6').style.display = 'block';
    }else{
        document.getElementById('error6').style.display = 'none';
    }
        
    if(email == ""){
        document.getElementById('error7').style.display = 'block';
    }else{
        document.getElementById('error7').style.display = 'none';
    }
        
    if(telefono == ""){
        document.getElementById('error8').style.display = 'block';
    }else{
        document.getElementById('error8').style.display = 'none';
    }
    
}

function validar_final_3(){
    var fecha = document.getElementById('fecha').value;
    var producto_v = document.getElementById('producto_v').value;
    var cantidad = document.getElementById('cantidad').value;
    var vendedor_v = document.getElementById('vendedor_v').value;
            
    if(fecha == ""){  
        document.getElementById('error9').style.display = 'block';
    }else{
        document.getElementById('error9').style.display = 'none';
    }
            
    if(cantidad == ""){
        document.getElementById('error11').style.display = 'block';
    }else{
        document.getElementById('error11').style.display = 'none';
    }

                
    if(fecha!="" && cantidad!="")
    llenarventa();
}

function llenararticulo(){
    var nombre = document.getElementById('nombre').value;
    var marca = document.getElementById('marca').value;
    var precio_compra = Number(document.getElementById('precioc').value);
    var stock = Number(document.getElementById('stock').value);
    var precio_venta = (precio_compra) + (precio_compra * 0.3);


    var articulo = {
        nombre: nombre,
        marca: marca,
        precio_compra: precio_compra,
        precio_venta: precio_venta,
        stock: stock
    }

    this.bodega.push(articulo);
    console.clear();
    console.log(this.bodega);

    document.getElementById('nombre').value = "";
    document.getElementById('marca').value = "";
    document.getElementById('precioc').value = "";
    document.getElementById('stock').value = "";

    mostrara();
    llenar_s();
    validar_final_1();
}

var bodega = []

function mostrara(){
    var mensaje = "";
    document.getElementById('datosa').innerHTML = "";
    var largo = this.bodega.length;

    for(con=0; con<largo; con++){
        mensaje += `
        <tr>
        <td>` + this.bodega[con].nombre +
        ` 
        </td>
        <td>` + this.bodega[con].marca +
        ` 
        </td>
        <td>` + this.bodega[con].precio_compra +
        ` 
        </td>
        <td>` + this.bodega[con].precio_venta +
        ` 
        </td>
        <td>` + this.bodega[con].stock +
        ` 
        </td>
        </tr>
        `;
    }

    document.getElementById('datosa').innerHTML = mensaje;
}

function llenarvendedor(){
    var nombrev = document.getElementById('nombrev').value;
    var cedula = Number(document.getElementById('cedula').value);
    var email = document.getElementById('email').value;
    var telefono = Number(document.getElementById('telefono').value);
    var vendedor = {
        nombrev: nombrev,
        cedula: cedula,
        email: email,
        telefono: telefono
    }

    this.empleados.push(vendedor);
    console.clear();
    console.log(this.empleados);

    document.getElementById('nombrev').value = "";
    document.getElementById('cedula').value = "";
    document.getElementById('email').value = "";
    document.getElementById('telefono').value = "";

    mostrarv();
    llenar_s();
    validar_final_2();
}

var empleados = []

function mostrarv(){
    var mensaje = "";
    document.getElementById('datosv').innerHTML = "";
    var largo = this.empleados.length;

    for(con=0; con<largo; con++){
        mensaje += `
        <tr>
        <td>` + this.empleados[con].nombrev +
        ` 
        </td>
        <td>` + this.empleados[con].cedula +
        ` 
        </td>
        <td>` + this.empleados[con].email +
        ` 
        </td>
        <td>` + this.empleados[con].telefono +
        ` 
        </td>
        </tr>
        `;
    }

    document.getElementById('datosv').innerHTML = mensaje;
}

function llenar_s(){
    const producto_s = document.getElementById('producto_v');
    const vendedor_s = document.getElementById('vendedor_v');

    producto_s.innerHTML = '';
    vendedor_s.innerHTML = '';

    bodega.forEach(articulo => {
        const option = document.createElement('option');
        option.value = articulo.nombre;
        option.textContent = articulo.nombre;
        producto_s.appendChild(option);
    });

    empleados.forEach(vendedor => {
        const option = document.createElement('option');
        option.value = vendedor.nombrev;
        option.textContent = vendedor.nombrev;
        vendedor_s.appendChild(option);
    });
}

function llenarventa(){
    var fecha = document.getElementById('fecha').value;
    var producto = document.getElementById('producto_v').value;
    var cantidad = Number(document.getElementById('cantidad').value);
    var vendedor = document.getElementById('vendedor_v').value;

    const producto_s = bodega.find((articulo) => articulo.nombre === producto);
    const vendedor_s = empleados.find((vendedor) => v.nombrev === vendedor);

    var subtotal = producto_s.precio_venta * cantidad;
    const iva = subtotal * 0.19;
    var total = subtotal + iva;

    var venta = {
        fecha: fecha,
        producto: producto,
        cantidad: cantidad,
        subtotal: subtotal,
        iva: iva,
        total: total,
        vendedor: vendedor
    }

    this.r_ventas.push(venta);
    console.clear();
    console.log(this.r_ventas);

    document.getElementById('fecha').value = '';
    document.getElementById('cantidad').value = '';

    mostrarven();

}

var r_ventas = []

function mostrarven(){
    var mensaje = "";
    document.getElementById('datosven').innerHTML = "";
    var largo = this.r_ventas.length;

    for(con=0; con<largo; con++){
        mensaje += `
        <tr>
        <td>` + this.r_ventas[con].fecha +
        ` 
        </td>
        <td>` + this.r_ventas[con].producto +
        ` 
        </td>
        <td>` + this.r_ventas[con].cantidad +
        ` 
        </td>
        <td>` + this.r_ventas[con].subtotal +
        ` 
        </td>
        <td>` + this.r_ventas[con].iva +
        ` 
        </td>
        <td>` + this.r_ventas[con].total +
        ` 
        </td>
        <td>` + this.r_ventas[con].vendedor +
        ` 
        </td>
        </tr>
        `;
    }

    document.getElementById('datosven').innerHTML = mensaje;
}

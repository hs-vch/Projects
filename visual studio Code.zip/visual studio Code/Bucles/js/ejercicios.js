function mostrar(datos) {
    switch (datos) {
        case 1:
            document.getElementById('enunciado1').style.display = 'block';
            document.getElementById('enunciado2').style.display = 'none';
            document.getElementById('enunciado3').style.display = 'none';
            document.getElementById('enunciado4').style.display = 'none';
            document.getElementById('enunciado5').style.display = 'none';
            break
        case 2:
            document.getElementById('enunciado2').style.display = 'block';
            document.getElementById('enunciado1').style.display = 'none';
            document.getElementById('enunciado3').style.display = 'none';
            document.getElementById('enunciado4').style.display = 'none';
            document.getElementById('enunciado5').style.display = 'none';
            break
        case 3:
            document.getElementById('enunciado3').style.display = 'block';
            document.getElementById('enunciado2').style.display = 'none';
            document.getElementById('enunciado1').style.display = 'none';
            document.getElementById('enunciado4').style.display = 'none';
            document.getElementById('enunciado5').style.display = 'none';
            break
        case 4:
            document.getElementById('enunciado4').style.display = 'block';
            document.getElementById('enunciado2').style.display = 'none';
            document.getElementById('enunciado3').style.display = 'none';
            document.getElementById('enunciado1').style.display = 'none';
            document.getElementById('enunciado5').style.display = 'none';
            break
        case 5:
            document.getElementById('enunciado5').style.display = 'block';
            document.getElementById('enunciado2').style.display = 'none';
            document.getElementById('enunciado3').style.display = 'none';
            document.getElementById('enunciado4').style.display = 'none';
            document.getElementById('enunciado1').style.display = 'none';
            break



    }
}

function ejer1() {
    var num, con, mensaje;
    const limite0 = 0;
    const limite100 = 100;

    num = Number(prompt("Ingrese número"));

    if (num <= limite0 && num >= limite100) {
        alert("El número no corresponde");
    } else {
        mensaje = "<h5>Ejemplo FOR</h5>";
        for(con=num; con<=limite100; con++){
            mensaje += con + " | ";
        }
        mensaje += "<h5>Ejemplo WHILE</h5>";

        con = num;

        while(con<=limite100){
            mensaje += con + " | ";
            con++;
        }

        mensaje += "<h5>Ejemplo DO WHILE</h5>";
        con = num;
        do{
            mensaje += con + " | ";
            con++;
        }while(con<=limite100)
    }
    document.getElementById('resultado').innerHTML = mensaje;
}

function ejer2(){
    var num, con, mensaje;
    const limite = 100;

    num = Number(prompt("Ingrese un número"));

    //validar. El mejor para validar es while.

    while(num >= limite){
        num = Number(prompt("Ingrese un número"));
    }

    mensaje = "<h5>Ejemplo FOR</h5>";
    for(con=num; con<=limite; con++){
        mensaje += con + " | ";
        }
    
    document.getElementById('resultado').innerHTML = mensaje;
}

function ejer3(){
    var num, con, residuo, mensaje;
    const limite1 = 0;
    const limite2 = 100;

    num = Number(prompt("Ingrese un número"));

    //verificar 

    while(num <= limite1 || num >= limite2){
        num = Number(prompt("Ingrese un número"));
    }

    residuo = num % 2;

    mensaje = " ";
    
    if(residuo==0){
        for(con=num; con <= limite2; con +=2){
            mensaje += con + " | ";
        }

    }else{
        for(con=num+1; con <= limite2; con +=2){
            mensaje += con + " | ";
        }
    }

    document.getElementById('resultado').innerHTML = mensaje;
}
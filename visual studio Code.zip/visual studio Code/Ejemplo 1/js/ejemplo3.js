document.write(" Escriba un programa que obtenga tres numeros, los almacene en variables y luego calcule y muestre un reporte sobre su suma y su promeriod <br><br>");

let n1, n2, n3, suma, promedio

n1 = Number(prompt("Ingrese n1"));
n2 = Number(prompt("Ingrese n2"));
n3 = Number(prompt("Ingrese n3"));

suma = n1+n2+n3;
promedio = suma/3

document.write("El resultado de la suma es " + suma + "<br>");
document.write("El resultado del promedio es " + promedio);

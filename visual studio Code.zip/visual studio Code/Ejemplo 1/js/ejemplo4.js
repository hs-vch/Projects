document.write("El dueno de una tienda compra un articulo a un precio determinado. Obtener el precio en que lo debe vender para obtener una utilidad del 30% <br><br>");

var articulo, precio_c, precio_v, utilidad
const porcentaje_u = 0.3;

//pedir lo que desconozco y no se calcula 
articulo = prompt("Ingrese el articulo a llevar");
precio_c = Number(prompt("Ingrese el precio de compra del articulo"));

//proceso

utilidad = precio_c * porcentaje_u;
precio_v = precio_c + utilidad;

//muestro los resultados 

document.write("El precio de compra de " + articulo + " es de " + precio_c );
document.write("<br>la utilidad es $" + utilidad);
document.write("<br>El precio de venta de " + articulo + " es de $" + precio_v);
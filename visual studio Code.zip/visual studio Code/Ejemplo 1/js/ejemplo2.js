document.write("Si una caja de 100 lapices cuesta 10.000, si un cliente llega y pide N lapices, indicar cuanto le cuestan <br><br>");

var N, costo, v_unitario;
const caja = 100;
const p_caja = 10000;

v_unitario = p_caja / caja;

N = Number(prompt("Cuantos lapices desea"));

v_unitario = p_caja / caja; 
costo = v_unitario * N;

document.write(N + " Lapices cuestan $" + costo);
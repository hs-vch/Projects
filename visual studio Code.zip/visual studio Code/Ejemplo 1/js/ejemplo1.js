//document.write escribe en pantalla
document.write("pedir dos numeros y sumarlos y luego dividir por 2, mostrar resultado de la suma y la division <br>");
    
var n1, n2, suma, div; 
const n3 = 2;

//prompt captura información
//Number convierte en número

n1 = Number(prompt("Ingrese n1"));
n2 = Number(prompt("Ingrese n2"));

suma = n1 + n2; 
div = suma / n3;

document.write("El resultado de la suma es " + suma + "<br>");
document.write("El resultado de la división es " + div + "<br>");

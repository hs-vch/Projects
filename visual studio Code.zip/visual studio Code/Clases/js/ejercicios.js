function mostrar(datos) {
    switch (datos) {
        case 1:
            document.getElementById('ejercicio1').style.display = 'block';
            document.getElementById('ejercicio2').style.display = 'none';
            document.getElementById('ejercicio3').style.display = 'none';
            document.getElementById('ejercicio4').style.display = 'none';
            document.getElementById('ejercicio5').style.display = 'none';
            break
        case 2:
            document.getElementById('ejercicio2').style.display = 'block';
            document.getElementById('ejercicio1').style.display = 'none';
            document.getElementById('ejercicio3').style.display = 'none';
            document.getElementById('ejercicio4').style.display = 'none';
            document.getElementById('ejercicio5').style.display = 'none';
            break
        case 3:
            document.getElementById('ejercicio3').style.display = 'block';
            document.getElementById('ejercicio2').style.display = 'none';
            document.getElementById('ejercicio1').style.display = 'none';
            document.getElementById('ejercicio4').style.display = 'none';
            document.getElementById('ejercicio5').style.display = 'none';
            break
        case 4:
            document.getElementById('ejercicio4').style.display = 'block';
            document.getElementById('ejercicio2').style.display = 'none';
            document.getElementById('ejercicio3').style.display = 'none';
            document.getElementById('ejercicio1').style.display = 'none';
            document.getElementById('ejercicio5').style.display = 'none';
            break
        case 5:
            document.getElementById('ejercicio5').style.display = 'block';
            document.getElementById('ejercicio2').style.display = 'none';
            document.getElementById('ejercicio3').style.display = 'none';
            document.getElementById('ejercicio4').style.display = 'none';
            document.getElementById('ejercicio1').style.display = 'none';
            break

    }
}

function calcular_edad(){
    //funcion simple, no recibe parametros.
    var dian, mesn, yearn, edad, mensaje;
    const fechaa = new Date();
    const diaa = fechaa.getDate();
    const mesa = fechaa.getMonth() + 1;
    const yeara = fechaa.getFullYear();

    dian = Number(prompt("Ingrese dia de nacimiento"));
    mesn = Number(prompt("Ingrese mes de nacimiento"));
    yearn = Number(prompt("Ingrese año de nacimiento"));

    if (mesn < mesa) {
        edad = yeara - yearn;
    }else if (mesn > mesa){
        edad = yeara - yearn - 1;
    }else if (dian < diaa) {
        edad = yeara - yearn;
    }else if (dian > diaa){
        edad = yeara -yearn - 1;
    }else{
        alert("Feliz cumpleaños");
        edad = yeara - yearn;
    }

    mensaje = "La persona tiene una edad de " + edad;

    document.getElementById('resultado').innerHTML = mensaje;

}

function elegir(equipo){
    var mensaje;

    mensaje = "El equipo que escogio es " + equipo;

    document.getElementById('resultado').innerHTML = mensaje;

}

function elegir(equipo){
    var mensaje;

    mensaje = "El equipo que escogio es " + equipo;
    var men2 = retornar();

    document.getElementById('resultado').innerHTML = mensaje + " - " + men2;

}

function retornar(){
    var mensaje = "<br> Ya se puede matricular";

    return mensaje;

}

function pulsasiones(){
    //switch
    var sexo, edad, mensaje, n_pul;
    const segundos = 10;

    edad = Number(prompt("Ingrese la edad"));
    sexo = prompt("Ingrese F para Femenino o M para Masculino");
    
    switch(sexo) {
        case "f":
        case "F":
            sexo = "Femenino"
            n_pul = (220-edad)/segundos;
            mensaje = "La persona pertenece al sexo " + sexo + " y su número de pulsaciones en 10 segundos es " + n_pul;
        break; 
        case "m":
        case "M":
            sexo = "Masculino"
            n_pul = (210-edad)/segundos;
            mensaje = "La persona pertenece al sexo " + sexo + " y su número de pulsaciones en 10 segundos es " + n_pul;
        break;
        default:
            alert("Ingreso un caracter equivocado");
            mensaje = "Ingreso un caracter equivocado";
        break;
    }

    document.getElementById('resultado').innerHTML = mensaje;

}

function calcular_edad2(){
    //funcion switch.
    var dian, mesn, yearn, edad, mensaje;
    const fechaa = new Date();
    const diaa = fechaa.getDate();
    const mesa = fechaa.getMonth() + 1;
    const yeara = fechaa.getFullYear();

    dian = Number(prompt("Ingrese dia de nacimiento"));
    mesn = Number(prompt("Ingrese mes de nacimiento"));
    yearn = Number(prompt("Ingrese año de nacimiento"));

    switch(true) {
        case mesn < mesa:
            edad = yeara - yearn;
        break;
        case mesn > mesa:
            edad = yeara - yearn - 1;
        break;
        case dian < diaa:
            edad = yeara - yearn;
        break;
        case dian > diaa:
            edad = yeara - yearn - 1;
        break;
        default:
            alert("Feliz cumpleaños");
            edad = yeara - yearn;
        break;
    }

    mensaje = "La persona tiene una edad de " + edad;

    document.getElementById('resultado').innerHTML = mensaje;
}



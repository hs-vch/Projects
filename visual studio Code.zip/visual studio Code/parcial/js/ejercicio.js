document.write("Hacer un algoritmo que reciba el nombre por medio de un bucle e imprima en lista el nombre, y imprima cuantas letras tiene <br>");

var n, largo, mensaje;

n = prompt("Ingrese su nombre");

largo = n.length;
mensaje = " ";

for(var i = 0; i < largo; i++){
    mensaje += n[i] + "<br>";

}



document.write("El nombre es " + n);
document.write("<br> El número de letras es " + largo + " letras <br>");
document.write(mensaje);
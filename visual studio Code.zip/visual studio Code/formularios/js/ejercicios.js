function mostrar(dato){
    switch(dato){
        case 1:
            document.getElementById('enun1').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
        break;
        case 2:
            document.getElementById('enun2').style.display = 'block';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
        break;
        case 3:
            document.getElementById('enun3').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
        break;
        case 4:
            document.getElementById('enun4').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
        break;
        case 5:
            document.getElementById('enun5').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
        break;
    }
}


///ejercicio 2
///---validar formulario
function validar_eje2(){
    var num1 = Number(document.getElementById('num1').value);
    var num2 = Number(document.getElementById('num2').value);


    if(num1 == ""){
        document.getElementById('error1').style.display = 'block';
    }else{
        document.getElementById('error1').style.display = 'none';
    }

    if(num2 == ""){
        document.getElementById('error2').style.display = 'block';
    }else{
        document.getElementById('error2').style.display = 'none';
    }

    if(num1!="" && num2!=""){
        var suma = num1 + num2;
        document.getElementById('resultado').innerHTML = 'El resultado de la suma es ' + suma;
        document.getElementById('num1').value = "";
        document.getElementById('num2').value = "";
    }

}


//ejercicio 3
function validar_eje3(){
    var fechan = document.getElementById('fecha_n').value;
    
    if(fechan == ""){
        document.getElementById('error3').style.display = 'block';
    }else{
        document.getElementById('error3').style.display = 'none';
        edad(fechan);
    }
}

function edad(fechan){
    var fn = fechan.split("-");
    var dian = fn[2];
    var mesn = fn[1];
    var yearn = fn[0];

    var fa = new Date();
    var diaa = fa.getDate();
    var mesa = fa.getMonth()+1;
    var yeara = fa.getFullYear();
    var edad = 0;

    switch(true){
        case mesn<mesa:
            edad = yeara - yearn;
        break;
        case mesn > mesa:
            edad = yeara - yearn - 1;
        break;
        case dian<diaa:
            edad = yeara - yearn;
        break;
        case dian>diaa:
            edad = yeara - yearn - 1;
        break;
        default:
            edad = yeara - yearn;
        break;
    }

    document.getElementById('resultado').innerHTML = 'La edad de la persona es ' + edad;

}

//ejercicio 4
function validar_eje4(){
    var producto = document.getElementById('producto').value;
    
    if(producto == ""){
        document.getElementById('error4').style.display = 'block';
    }else{
        document.getElementById('error4').style.display = 'none';
        calcular_total(producto);
    }
}

function calcular_total(producto){
    var precio, cantidad, total, mensaje;
    switch(producto){
        case "Pantalón":
            precio = 50000;
        break;
        case "Camisa":
            precio = 20000;
        break;
        case "Zapatos":
            precio = 100000;
        break;
    }
    cantidad = Number(prompt("Ingrese la cantidad a llevar"));
    total = precio * cantidad;

    mensaje = "El producto a llevar es " + producto;
    mensaje += "<br>La cantidad a llevar es " + cantidad;
    mensaje += "<br>El precio es $" + precio + ".oo";
    mensaje += "<br><b>El total a pagar es $" + total + ".oo </b>";
    
    document.getElementById('resultado').innerHTML=mensaje;
}
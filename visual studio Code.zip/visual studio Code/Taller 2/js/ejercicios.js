function mostrar(dato){
    switch(dato){
        case 1:
            document.getElementById('enun1').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 2:
            document.getElementById('enun2').style.display = 'block';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 3:
            document.getElementById('enun3').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 4:
            document.getElementById('enun4').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 5:
            document.getElementById('enun5').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        break;
        case 6:
            document.getElementById('enun6').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
            document.getElementById('enun7').style.display = 'none';
        case 7:
            document.getElementById('enun7').style.display = 'block';
            document.getElementById('enun2').style.display = 'none';
            document.getElementById('enun3').style.display = 'none';
            document.getElementById('enun4').style.display = 'none';
            document.getElementById('enun1').style.display = 'none';
            document.getElementById('enun6').style.display = 'none';
            document.getElementById('enun5').style.display = 'none';
        break;
    }
}

function calcularventa(){

    var producto = prompt("Ingrese el nombre del producto");
    var precio = Number(prompt("Ingrese el precio del producto"));
    var cantidad = Number(prompt("Ingrese cantidad a llevar"));
    var subtotal = precio * cantidad;

    const desc1 = 0.15;
    const desc2 = 0.05;
    
    if(cantidad > 20){
        descuento = subtotal * desc1; 
    }else if(cantidad > 10){
        descuento = subtotal * desc2;
    }else{
        descuento = 0;
    }
    
    var total = subtotal - descuento;
    
    mensaje = "Producto: " + producto;
    mensaje += "<br>Precio: $" + precio;
    mensaje += "<br>Cantidad: " + cantidad;
    mensaje += "<br>Subtotal: $" + subtotal;
    mensaje += "<br>Descuento: $" + descuento
    mensaje += "<br>Total: $" + total;
    
    document.getElementById('resultado').innerHTML = mensaje;
}

function contarnumeros(){
    var n_i, n_f, con, mensaje;
    
    n_i = Number(prompt("Ingrese el número inicial"));
    n_f = Number(prompt("Ingrese el número final"));
 
    mensaje = " ";

   if(n_i <= n_f){
    for(con=n_i; con <= n_f; con ++){
        mensaje += con + " | ";
    }
   }else{
    for(con=n_i ; con >= n_f; con --){
        mensaje += con + " | ";
    }
   }

   document.getElementById('resultado').innerHTML = mensaje;
}

function esprimo(numero){

    var n1, primo;
    base = 0;
    primo=true;
    n1 = Number(prompt("Ingrese un numero"));

    for (base=2; base <= n1; base++){
        if(n1 % 2 === 0){
            primo=false;


        }
    }

    if(primo==true){
        mensaje = "El número " + n1 + " es primo.";
    }else{
        mensaje = "El número " + n1 + " no es primo.";
    }

    document.getElementById('resultado').innerHTML = mensaje;
}

function ejer_2(){

    var n = Number(document.getElementById('num1').value);
    var contador = 0;
    var n_a = n;
    var mensaje;

    mensaje = " ";

    while (contador < 5){
        if(n_a % 2 !== 0 && n_a % 3 ===0){
            mensaje += n_a + " | ";
            contador++;
        }
        n_a++;
    }

    document.getElementById('resultado').innerHTML = mensaje;

}

function cont_ej3(){

    var ni = Number(document.getElementById('numi').value);
    var nf = Number(document.getElementById('numf').value);

    mensaje = "Contador : <br>";

    if(ni < nf){
        for(con = ni; con <= nf; con++){
            mensaje += con + " | ";
        }
    }else{
        for(con = nf; con <= ni; con++){
            mensaje += con + " | ";
        }
    }

    mensaje += "<br><br>Números pares : "

    var conp = 0;
    var sumap = 0;

    if(ni < nf){
        for (var conp = ni; conp <= nf; conp++){
            if( conp % 2!==0){
                conp++;
                sumap += conp;
                mensaje += conp + " | ";
            }
            console.log(conp % 2 !==0 ? conp : '')
        }
    }else{
        for (var conp = nf; conp <= ni; conp++){
            if( conp % 2!==0){
                conp++;
                sumap += conp;
                mensaje += conp + " | ";
            }
            console.log(conp % 2 !==0 ? conp : '')
        }
    }

    mensaje += "<br>Suma : " + sumap;

    mensaje += "<br><br>Números impares : "

    var conimp = 0;
    var sumaimp = 0;

    if(ni < nf){
        for (var conimp = ni; conimp <= nf; conimp++){
            if( conimp % 2 === 0){
                conimp++;
                sumaimp += conimp;
                mensaje += conimp + " | ";
            }
            console.log(conimp % 2===0 ? conp : '')
        }
    }else{
        for (var conimp = nf; conimp <= ni; conimp++){
            if( conimp % 2 === 0){
                conimp++;
                sumaimp += conimp;
                mensaje += conimp + " | ";
            }
            console.log(conimp % 2===0 ? conimp : '')
        }
    }

    mensaje += "<br>Suma : " + sumaimp;
    
    document.getElementById('resultado').innerHTML = mensaje;

}

function horas_t(){
    var h_t = Number(document.getElementById('horast').value);
    var valor_h = Number(document.getElementById('valorh').value);
    var salario, h_e, mensaje;
    const l_h = 54;
    const incremento = 0.5;

    h_e = h_t - l_h;
    salario = (l_h * valor_h) + (h_e * valor_h * incremento)

    mensaje = "El salario del trabajador es de " + salario;

    document.getElementById('resultado').innerHTML = mensaje;

}

function suma_p(){
    var n1 = Number(document.getElementById('numero').value);
    const limite_p = 30;
    var potencias = [];
    var suma = 0;
    var mensaje;

    mensaje = " ";

    for(var i = 0; i < limite_p; i++){
        var potencia = n1**i;
        potencias.push(potencia);
        suma += potencia;
    }

    mensaje += "Potencias : " + potencias.join(", "); 
    mensaje += "<br><br> Suman: " + suma;

    document.getElementById('resultado').innerHTML = mensaje;

}

function notasp(){
    var suma_a = 0
    var suma_d = 0 
    var con_a = 0 
    var con_d = 0 
    var mensaje;

    mensaje = " ";

    for (var n = 1; n <= 10; n++){
        var nota = parseFloat(document.getElementById('nota'+n).value);

        if (nota >= 3){
            suma_a += nota;
            con_a++;
        }else{
            suma_d += nota;
            con_d++;
        }
    }

    var promedio_a = suma_a / con_a;
    var promedio_d = suma_d / con_d;

    mensaje += "El promedio de las notas aprobadas es: " + promedio_a;
    mensaje += "<br><br>El promedio de las notas desaprobadas es: " + promedio_d;

    document.getElementById('resultado').innerHTML = mensaje;
}

function costominutos(){
    var min = Number(document.getElementById('minutos').value);
    var m_a, costo_llamada, mensaje;
    const l_min = 3;
    const costo_min = 0.50;
    const adicional = 0.10;

    m_a = min - l_min;

    costo_llamada = (l_min * costo_min) + (costo_min + adicional * m_a);

    mensaje = "El costo de la llamada es de " + costo_llamada;

    document.getElementById('resultado').innerHTML = mensaje;


}


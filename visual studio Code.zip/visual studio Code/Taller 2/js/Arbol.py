class TreeNode:
    def __init__(self, value):
        self.value = value
        self.children = []

class Tree:
    def __init__(self):
        self.root = None

    def add_child(self, parent, child):
        if self.root is None:
            self.root = TreeNode(parent)
        parent_node = self.find(self.root, parent)
        if parent_node:
            parent_node.children.append(TreeNode(child))

    def find(self, node, value):
        if node is None:
            return None
        if node.value == value:
            return node
        for child in node.children:
            found = self.find(child, value)
            if found:
                return found
        return None

# Construcción del árbol
tree = Tree()
tree.root = TreeNode('A')
tree.add_child('A', 'B')
tree.add_child('A', 'C')
tree.add_child('A', 'D')
tree.add_child('A', 'E')
tree.add_child('B', 'F')
tree.add_child('B', 'G')
tree.add_child('D', 'H')
tree.add_child('E', 'I')
tree.add_child('E', 'J')
tree.add_child('J', 'K')

def preorder(node):
    if node:
        print(node.value, end=' ')
        for child in node.children:
            preorder(child)

def inorder(node):
    if node:
        n = len(node.children)
        for i in range(n):
            inorder(node.children[i])
            if i == n - 1:
                print(node.value, end=' ')

def postorder(node):
    if node:
        for child in node.children:
            postorder(child)
        print(node.value, end=' ')

def prufer_code(node):
    degree = {}
    leaves = []
    for n in get_nodes(node):
        degree[n] = len(n.children)
        if degree[n] == 0:
            leaves.append(n)
    leaves.sort(key=lambda x: x.value)

    prufer = []
    while len(degree) > 2:
        leaf = leaves.pop(0)
        for parent in get_nodes(node):
            if leaf in parent.children:
                prufer.append(parent.value)
                degree[parent] -= 1
                if degree[parent] == 0:
                    leaves.append(parent)
                    leaves.sort(key=lambda x: x.value)
                break
        del degree[leaf]

    return prufer

def get_nodes(node):
    if node:
        nodes = [node]
        for child in node.children:
            nodes.extend(get_nodes(child))
        return nodes
    return []

print("Preorden:")
preorder(tree.root)
print("\nInorden:")
inorder(tree.root)
print("\nPostorden:")
postorder(tree.root)
print("\nCodificación de Prüfer:", prufer_code(tree.root))
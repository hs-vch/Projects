
package segundoparcial;

import javax.swing.JOptionPane;

public class ejercicio {
    
    int [] numeros = new int[10];
    int sumaimpares = 0, impares = 0, pares= 0;
    double promedio;

    public ejercicio() {
    }

    public int[] getNumeros() {
        return numeros;
    }

    public void setNumeros(int[] numeros) {
        this.numeros = numeros;
    }

    public int getSumaimpares() {
        return sumaimpares;
    }

    public void setSumaimpares(int sumaimpares) {
        this.sumaimpares = sumaimpares;
    }

    public int getImpares() {
        return impares;
    }

    public void setImpares(int impares) {
        this.impares = impares;
    }

    public int getPares() {
        return pares;
    }

    public void setPares(int pares) {
        this.pares = pares;
    }
    
    

    public void pedirNumeros() {
        for (int i = 0; i < 10; i++) {
            numeros[i] = Integer.parseInt(JOptionPane.showInputDialog("Digite el numero: "));
        }
    }

    public void numerosPares() {
        System.out.print("Los numeros pares digitados en el vector son: ");
        for (int num : numeros) {
            if (num % 2 == 0) {
                System.out.print(num + ", ");
                pares++;
            }
        }
        System.out.println();
    }
    
    public void sumaImpares() { 
        for (int num : numeros) {
            if (num % 2 != 0) {
                sumaimpares += num;
                impares++;
            }
        }
    }
    
    public void cantidadParImpar() {
        System.out.println("Existen " + pares + " numeros pares en el vector");
        System.out.println("Existen " + impares + " numeros impares en el vector");
    }
    
    public void promedioSumaImpares() {
        if (impares > 0) {
            promedio = sumaimpares / impares;
            System.out.println("El promedio de los números impares es: " + promedio);
        } else {
            System.out.println("No hay números impares en el vector para calcular el promedio.");
        }
    }
    
    public void mostrarnumeros() {
        System.out.print("Los numeros ingresados son: ");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
   

    public void ordenarVector() {
        for (int i = 0; i < numeros.length - 1; i++) {
            for (int j = 0; j < numeros.length - i - 1; j++) {
                if (numeros[j] > numeros[j + 1]) {
                    int temp = numeros[j];
                    numeros[j] = numeros[j + 1];
                    numeros[j + 1] = temp;
                }
            }
        }
        
        System.out.print("Los numeros ordenados de menor a mayor son: ");
        for (int num : numeros) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
    
   
}
    
   
    
    


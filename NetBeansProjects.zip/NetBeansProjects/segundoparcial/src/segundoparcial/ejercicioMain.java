
package segundoparcial;


public class ejercicioMain {
 
    public static void main(String[] args) {
        
        ejercicio num = new ejercicio();
        
        num.pedirNumeros();
        num.numerosPares();
        num.sumaImpares();
        num.cantidadParImpar();
        num.mostrarnumeros();
        num.ordenarVector();

    }
}


package arreglos;

public class matriz {
    public int matriz[][] = new int[5][3];
    
    //largo 5
    
    public void llenar(int pos, int num1, int num2){
        this.matriz[pos][0] = num1;
        this.matriz[pos][1] = num2;
        this.matriz[pos][2] = num1 * num2;
    }  
}

package arreglos;

import javax.swing.JOptionPane;

public class Arreglos {

    
    public static void main(String[] args) {
        
        String ejer = JOptionPane.showInputDialog("Escriba el número del ejercicio");
        String Mensaje = "";
        
        switch(ejer){
            case "1":
                arreglo obj1 = new arreglo();

                obj1.llenar(0, "Andrés");

                for(int i=0; i<obj1.arreglo.length; i++){
                    Mensaje = Mensaje + obj1.arreglo[i] + "\n";    
                }
                
                JOptionPane.showMessageDialog(null, Mensaje);
            break;
            case "2":
                String nombre;

                arreglo obj2 = new arreglo();

               for(int i=0; i<obj2.arreglo.length; i++){
                    nombre = JOptionPane.showInputDialog("Escriba nombre");    
                    obj2.llenar(i, nombre);
                }

                
                for(int i=0; i<5; i++){
                    Mensaje = Mensaje + obj2.arreglo[i] + "\n";    
                }

                JOptionPane.showMessageDialog(null, Mensaje);
            break;
            case "3":
                matriz obj3 = new matriz();

                obj3.llenar(0, 2, 3);

                for(int i=0; i<obj3.matriz.length; i++){
                    Mensaje = Mensaje + obj3.matriz[i][0] + " * " + obj3.matriz[i][1] + " = " + obj3.matriz[i][2] + "\n";    
                }
                
                JOptionPane.showMessageDialog(null, Mensaje);
            break;
            case "4":
                int n1, n2;
                
                n1 = Integer.parseInt(JOptionPane.showInputDialog("Escriba n1"));
                n2 = Integer.parseInt(JOptionPane.showInputDialog("Escriba n2"));
                
                matriz obj4 = new matriz();

               for(int i=0; i<obj4.matriz.length; i++){
                    obj4.llenar(i, n1, n2);
                    n2++;
                }

                
                for(int i=0; i<5; i++){
                    Mensaje = Mensaje + obj4.matriz[i][0] + " * " + obj4.matriz[i][1] + " = " + obj4.matriz[i][2] + "\n";    
                }

                JOptionPane.showMessageDialog(null, Mensaje);
            break;
            case "5":
                String nom;
                
                listas obj5 = new listas();
                
                for(int i=1; i<=4; i++){
                    nom = JOptionPane.showInputDialog("Escriba nombre");
                    obj5.llenar(nom);
                }
                
                //System.out.println(obj5.nombres);
                for(int j=0; j<obj5.nombres.size(); j++){
                    Mensaje = Mensaje + obj5.nombres.get(j) + "\n";
                }
                
                //JOptionPane.showMessageDialog(null, obj5.nombres);
                JOptionPane.showMessageDialog(null, Mensaje);
                
                ///////////////////////quitar datos de la lista
                
                Mensaje = "";
                
                obj5.quitar_dato("Susan");
                
                for(int j=0; j<obj5.nombres.size(); j++){
                    Mensaje = Mensaje + obj5.nombres.get(j) + "\n";
                }
                
                //JOptionPane.showMessageDialog(null, obj5.nombres);
                JOptionPane.showMessageDialog(null, Mensaje);
                
                ////////////////saber si tiene datos
                
                obj5.limpiar();
                
                boolean validar = obj5.tiene_datos();
                
                if(validar == true){
                    JOptionPane.showMessageDialog(null, "la lista NO tiene datos");
                }else{
                    JOptionPane.showMessageDialog(null, "la lista tiene datos");
                }   
                
            break;
        }
        
        
        
    }
    
}


package arreglos;

import java.util.*;

public class listas {
    
    public List<String> nombres;

    public listas() {
        this.nombres = new ArrayList<String>();
    }
    
    
    public void llenar(String nombre){
        this.nombres.add(nombre);
    }
    
    
    public void quitar_pos(int pos){
        this.nombres.remove(pos);
    }
    
    public void quitar_dato(String nombre){
        this.nombres.remove(nombre);
    }
    
    public void limpiar(){
        this.nombres.clear();
    }
    
    public boolean tiene_datos(){
        return this.nombres.isEmpty();
    }
    
    public void cambiar_dato(String nombre){
        this.nombres.set(1, nombre);
    }
    
    
    
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arreglos;

/**
 *
 * @author andres
 */
public class arreglo {
    
    public String arreglo[] = new String[5];
    
    //["", "", "", "", ""]
    //  0   1   2   3   4
    
    public void llenar(int pos, String nombre){
        arreglo[pos]=nombre;
    }  
    
    
    
    
}

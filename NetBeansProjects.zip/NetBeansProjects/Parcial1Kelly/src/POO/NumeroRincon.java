
package POO;

import javax.swing.JOptionPane;

public class NumeroRincon {
    
    int n1, n2, resta, multiplicacion, suma, edad;
    String nombre;
    

public void leerNumero(){
    n1 = Integer.parseInt(JOptionPane.showInputDialog("Digite el primer número: "));
    n2 = Integer.parseInt(JOptionPane.showInputDialog("Digite el segundo número: "));
}

public void verificarnumeros(){
     if( n1==n2 ){
         System.out.println("Los numeros son iguales");
        for(int i = 1; i<=n1; i++){
            System.out.print(i + " | ");
        }
        System.out.println();
     }else{
         resta = n1 - n2;
     }
}  

public void CalcularResultado(){
    
  
    if(resta%2!=0 && resta<10){
        multiplicacion = n1 * n2;
        System.out.println("\n El resultado de la resta es impar, y la multiplicacion entre los numeros es " + multiplicacion);
    }else if(resta%2!=0 && resta >10){
         System.out.println("Es impar");
    }else{
        suma = n1 + n2;
         System.out.println("\n El resultado de la resta es par, y la suma entre los numeros es " + suma);
        
    }
    
}

public void edadsofia(){
    nombre = JOptionPane.showInputDialog("Ingrese su nombre: ");
    edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su edad "));
    
    
    if(edad<18){
        System.out.println(nombre + " es menor de edad");
    }else{
        System.out.println(nombre + " es mayor de edad");
    }
    
}

}

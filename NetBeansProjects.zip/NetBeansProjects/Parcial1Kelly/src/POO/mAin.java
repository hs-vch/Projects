
package POO;


public class mAin {

   
    public static void main(String[] args) {
        
        NumeroRincon nr = new NumeroRincon();
        
        nr.leerNumero();
        nr.verificarnumeros();
        nr.CalcularResultado();
        
        NumeroRincon erincon = new NumeroRincon();
        
        erincon.edadsofia();
        
       
    }
    
}

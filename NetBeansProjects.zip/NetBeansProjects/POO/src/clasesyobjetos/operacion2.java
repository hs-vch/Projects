
package clasesyobjetos;

public class operacion2 {
    
    int suma;
    int resta;
    int mult;
    int div;
    
    
    public void sumar(int n1, int n2){
        suma = n1 + n2;
        
    }
    
    public void restar(int n1, int n2){
        resta = n1 - n2;
    }
    
    public void multiplicar(int n1, int n2){
        mult = n1 * n2;
    }
    
    public void dividir(int n1, int n2){
        div = n1 / n2;
    }
    
    public void mostrarresultados(){
        System.out.println("La suma es: " + suma);
        System.out.println("La resta es: " + resta);
        System.out.println("La multiplicacion es: " + mult);
        System.out.println("La division es: " + div);
    }
    
}

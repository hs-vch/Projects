
package clasesyobjetos;

import javax.swing.JOptionPane;

public class operacion {
    
    int num1;
    int num2;
    int suma;
    int resta;
    int mult;
    int div;
    
    public void leerNumero(){
        num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite el número 1: "));
        num2 = Integer.parseInt(JOptionPane.showInputDialog("Digite el número 2: "));
        
        }
    
    public void sumar(){
        suma=num1 + num2;
    }
    
    public void dividir(){
        div= num1 / num2;
    }
    
    public void restar(){
        resta = num1 - num2;
    }
    
    public void multiplicar(){
        mult = num1 * num2;
    }
    
    public void mostrarresultado(){
        System.out.println("La suma es: " + suma);
        System.out.println("La resta es: " + resta);
        System.out.println("La multiplicacion es: " + mult);
        System.out.println("La division es: " + div);
    }
    
    }
    

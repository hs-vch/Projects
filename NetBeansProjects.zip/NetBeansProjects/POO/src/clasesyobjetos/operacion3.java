
package clasesyobjetos;

public class operacion3 {
    
    public int sumar(int n1, int n2){
        int suma = n1 + n2;
        return suma;
    }
    
    public int restar(int n1, int n2){
        int resta = n1 - n2;
        return resta;
    }
    
    public int dividir(int n1, int n2){
        int div = n1 / n2;
        return div;
    }
    
    public int multiplicar(int n1, int n2){
        int mult= n1*n2;
        return mult;
    }
    
    public void mostrarresultados(int suma, int resta, int div, int mult){
        System.out.println("La suma es: " + suma);
        System.out.println("La resta es: " + resta);
        System.out.println("La multiplicacion es: " + mult);
        System.out.println("La division es: " + div);
        
    }
    
}

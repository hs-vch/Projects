
package clasesyobjetos;

public class Coche {
    String color;
    String marca;
    int km;
    
    public static void main(String[] args){
        Coche Coche1 = new Coche();
        
        Coche1.color = "blanco";
        Coche1.marca = "Renault";
        Coche1.km = 0; 
        
        System.out.println("El color del coche 1 es:" + Coche1.color);
        System.out.println("La marca del coche 1 es:" + Coche1.marca);
        System.out.println("El kilometraje del coche 1 es:" + Coche1.km);
        
         Coche Bus = new Coche();
         
         Bus.color = "verde";
         Bus.marca = "Mercedes";
         Bus.km = 5000;
         
         System.out.println("\n El color del megabus es:" + Bus.color);
         System.out.println("La marca del megabus es:" +  Bus.marca);
         System.out.println("El kilometraje del megabus es:" + Bus.km);
                
  
    }
    
}

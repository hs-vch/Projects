
package clasesyobjetos;

import javax.swing.JOptionPane;
public class MAIN2 {
    
    public static void main(String[]args){
        
        int primero = Integer.parseInt(JOptionPane.showInputDialog("Digite el primer numero: "));
        int segundo = Integer.parseInt(JOptionPane.showInputDialog("Digite el segundo numero: "));
        
        operacion2 op = new operacion2();
        
        op.sumar(primero, segundo);
        op.dividir(primero, segundo);
        op.restar(primero, segundo);
        op.multiplicar(primero, segundo);
        op.mostrarresultados();
    }
    
}

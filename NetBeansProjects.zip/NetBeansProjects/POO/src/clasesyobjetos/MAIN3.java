
package clasesyobjetos;

import javax.swing.JOptionPane;

public class MAIN3 {
    
    public static void main(String[]args){
        
        int primero = Integer.parseInt(JOptionPane.showInputDialog("Digite el primer numero: "));
        int segundo = Integer.parseInt(JOptionPane.showInputDialog("Digite el segundo numero: "));
        
        operacion3 op = new operacion3();
        
        int sum = op.sumar(primero, segundo);
        int di = op.dividir(primero, segundo);
        int mul = op.multiplicar(primero, segundo);
        int res = op.restar(primero, segundo);
        
        op.mostrarresultados(sum, res, di, mul);
                
        
    }
    
}

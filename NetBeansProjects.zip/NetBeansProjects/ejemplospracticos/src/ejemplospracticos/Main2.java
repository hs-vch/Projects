
package ejemplospracticos;

public class Main2 {
    
        public static void main(String[] args) {
        
        int [ ][ ]arregloCalif = {{87, 96, 70}, 
                                        {100, 83, 78}, 
                                        {85, 91, 76},
                                        {87, 92, 80},
                                        {70, 100, 91},
                                        {76, 84, 99},
                                        {98, 76, 77},
                                        {92, 81, 70},
                                        {93, 90, 78}};
        
        LibroCalificaciones2 miLibroCalificaciones = new LibroCalificaciones2("CS101 Introduccion a la programacion en Java", arregloCalif);
        
        System.out.printf("Bienvenido al libro de calificaciones para %n%s%n%n", miLibroCalificaciones.obtenerNombredelcurso());
        
        miLibroCalificaciones.procesarCalificaciones();

    }
    
}

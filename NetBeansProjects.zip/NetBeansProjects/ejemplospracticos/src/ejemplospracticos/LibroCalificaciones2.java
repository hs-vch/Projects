
package ejemplospracticos;


public class LibroCalificaciones2 {
    
    private String nombredelCurso;
    private int [ ][ ] calificaciones;

    public LibroCalificaciones2(String nombredelCurso, int[][] calificaciones) {
        this.nombredelCurso = nombredelCurso;
        this.calificaciones = calificaciones;
    }

    public void establecerNombredelcurso(String nombredelCurso){
        this.nombredelCurso = nombredelCurso;  
    }
    
    public String obtenerNombredelcurso(){
        return nombredelCurso;
    }
    
    public void procesarCalificaciones(){
        
        imprimirCalificaciones();

        System.out.printf("%n%s %d%n%s %d%n%n",
                "La calificacion mas baja es",
                obtenerMinima(),
                "La calificacion mas alta es",
                obtenerMaxima());
        
        imprimirGraficoBarras();          
        
    }
    
    public int obtenerMinima() {
        int caliBaja = calificaciones[0][0];
        
        for (int[] caliEstudiantes : calificaciones){
            for(int calificacion : caliEstudiantes){
                 if (calificacion < caliBaja){
                     caliBaja = calificacion;           
                 }
            }
        }
        return caliBaja;
    }
    
    public int obtenerMaxima(){
        int caliAlta = calificaciones[0][0];
        
        for (int[] caliEstudiantes : calificaciones){
            for(int calificacion : caliEstudiantes){
                 if (calificacion > caliAlta){
                     caliAlta = calificacion;           
                 }
            }
        }
        return caliAlta;
    }
    
    public double promedio(int[] conjuntoDeCalif){
        int total = 0;
        
        for (int calificacion : conjuntoDeCalif){
            
            total += calificacion;
            
        }
        return (double) total / conjuntoDeCalif.length;
    }
    
    public void imprimirGraficoBarras(){
        
        System.out.println("Distribucion de calificaciones en general ");
        
        int [ ] frecuencia =  new int[11];
        
        for (int[] caliEstudiantes : calificaciones){
            for(int calificacion : caliEstudiantes){
                ++frecuencia[calificacion/10];        
            }

        }
        
        for(int cuenta = 0; cuenta < frecuencia.length; cuenta++){
            
            if (cuenta == 10){
                System.out.printf("%5d : ", 100);
            }else{
                System.out.printf("%02d-%02d: ",
                        cuenta * 10, cuenta*10+9);
            }
            
            for(int estrellas =0; estrellas < frecuencia[cuenta]; estrellas++){
                System.out.print("*");
                
            }
            System.out.println();
        }
        
    }
    
    public void imprimirCalificaciones(){
        
        System.out.println("Las calificaciones son:");
        System.out.print("            "); 
        
        for(int prueba = 0; prueba < calificaciones[0].length; prueba++){
            System.out.printf("Prueba %d", prueba + 1);     
        }
          System.out.println("Promedio");
          
          for(int estudiante = 0; estudiante < calificaciones.length; estudiante++){
              System.out.printf("Estudiantes %2d", estudiante + 1);
              for(int prueba : calificaciones[estudiante]){
                  System.out.printf("%8d", prueba);
                  
              }
              double obpromedio = promedio(calificaciones[estudiante]);
              System.out.printf("%9.2f%n", obpromedio);
              
          }
    }
    

}

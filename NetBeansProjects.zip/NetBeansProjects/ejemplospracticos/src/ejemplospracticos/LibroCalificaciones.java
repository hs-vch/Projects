
package ejemplospracticos;

//Arreglo unidimensional


public class LibroCalificaciones {
    
    private String nombredelCurso;
    private int [ ] calificaciones;

    public LibroCalificaciones(String nombredelCurso, int[] calificaciones) {
        this.nombredelCurso = nombredelCurso;
        this.calificaciones = calificaciones;
    }
    
    public void establecerNombredelcurso(String nombredelCurso){
        this.nombredelCurso = nombredelCurso;  
    }
    
    public String obtenerNombredelcurso(){
        return nombredelCurso;
    }
    
    public void procesarCalificaciones(){
        
        imprimirCalificaciones();
        
        System.out.printf("%n El promedio de la clase es %.2f%n", promedio());

        System.out.printf("La calificacion mas baja es %d%n La calificacion mas alta es %d%n%n", obtenerMinima(), obtenerMaxima());
        
        imprimirGraficoBarras();          
        
    }
    
    public int obtenerMinima() {
        int caliBaja = calificaciones[0];
        
        for (int calificacion : calificaciones){
            if (calificacion < caliBaja){
                caliBaja = calificacion;
                
            }
        }
        return caliBaja;
    }
    
    public int obtenerMaxima(){
        int caliAlta = calificaciones[0];
        
        for(int calificacion : calificaciones){
            if(calificacion > caliAlta){
                caliAlta = calificacion;
            }
        }
        return caliAlta;   
    }
    
    public double promedio(){
        int total = 0;
        
        for (int calificacion : calificaciones){
            
            total += calificacion;
            
        }
        return (double) total / calificaciones.length;
    }
    
    public void imprimirGraficoBarras(){
        
        System.out.println("Distribucion de calificaciones");
        
        int [ ] frecuencia =  new int[11];
        
        for (int calificacion : calificaciones){
            ++frecuencia[calificacion/10];
        }
        
        for(int cuenta = 0; cuenta < frecuencia.length; cuenta++){
            
            if (cuenta == 10){
                System.out.printf("%5d : ", 100);
            }else{
                System.out.printf("%02d-%02d: ", cuenta * 10, cuenta*10+9);
            }
            
            for(int estrellas =0; estrellas < frecuencia[cuenta]; estrellas++){
                System.out.print("*");
                
            }  
            System.out.println();
        }
        
    }
    
    public void imprimirCalificaciones(){
        
        System.out.println("Las calificaciones son: %n%n");
        
        for(int estudiante = 0; estudiante < calificaciones.length; estudiante++){
            System.out.printf("Estudiante %2d: %3d%n", estudiante +1, calificaciones[estudiante]);
            
        }
    }
    

}


package ejemplos_java;

import ejemplos_java.paneles.p_principal;


public class Ejemplos_java {

    
    public static void main(String[] args) {
        
        //llamar al panel principal
        
        p_principal panel = new p_principal();
        
        panel.setVisible(true);
        
        
    }
    
}

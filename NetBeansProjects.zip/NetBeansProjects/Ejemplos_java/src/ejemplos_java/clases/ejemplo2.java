/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos_java.clases;

/**
 *
 * @author andres
 */
public class ejemplo2 {
    
    public int da, ma, ya, dn, mn, yn, edad;
    
    public ejemplo2(int da, int ma, int ya, int dn, int mn, int yn){
        this.da = da;
        this.ma = ma;
        this.ya = ya;
        this.dn = dn;
        this.mn = mn;
        this.yn = yn;
    }
    
    public void calcular_edad(){
        if(this.mn < this.ma && this.dn < this.da){
            this.edad = this.ya - this.yn;
        }else if(this.mn > this.ma && this.dn > this.da){
            this.edad = this.ya - this.yn - 1;
        }else{
            this.edad = this.ya - this.yn;
        }
    }
    
}

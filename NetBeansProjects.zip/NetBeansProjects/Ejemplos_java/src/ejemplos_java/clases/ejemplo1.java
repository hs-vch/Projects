/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplos_java.clases;

/**
 *
 * @author andres
 */
public class ejemplo1 {
    
    public int num1, num2, suma;
    
    public ejemplo1(int num1, int num2){
        this.num1 = num1;
        this.num2 = num2;
        this.suma = this.num1 + this.num2;
    }
    
}

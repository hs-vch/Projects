
package programaimc;

import javax.swing.JOptionPane;

public class MainImc {

  
    public static void main(String[] args) {
        
        ejerIMC ind = new ejerIMC();
        
       String nom = JOptionPane.showInputDialog("Escriba su nombre: ");
       int eda = Integer.parseInt(JOptionPane.showInputDialog("\n Escriba su edad: "));
       double pes =  Integer.parseInt(JOptionPane.showInputDialog("\n Escriba cuanto pesa: "));
       double altu=  Integer.parseInt(JOptionPane.showInputDialog("\n Escriba cuanto mide en cm: "));
       
       ind.setNombre(nom);
       ind.setEdad(eda);
       ind.setEstatura(altu);
       ind.setPeso(pes);
        
        ind.mayoredad(eda);
        ind.valorimc();

    }
    
}

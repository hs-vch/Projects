
package programaimc;


public class ejerIMC {
    
    String nombre, mensaje;
    int edad;
    double estatura, peso, IMC;

    public ejerIMC() {
    }

    public ejerIMC(String nombre, int edad, double estatura, double peso) {
        this.nombre = nombre;
        this.edad = edad;
        this.estatura = estatura;
        this.peso = peso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getEstatura() {
        return estatura;
    }

    public void setEstatura(double estatura) {
        this.estatura = estatura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
        
    public double IMCkelly(double altura, double peso){
           IMC = peso/Math.pow(estatura, 2);
        return IMC;
    }
    
    public void mayoredad(int edad){
        
        if(edad<18){
            System.out.println("Hola " + nombre + ", eres menor de edad, tu peso es " + peso + " tu estatura es de " + estatura);
        }else{
            System.out.println("Hola " + nombre + ", eres mayor de edad, tu peso es " + peso + " tu estatura es de " + estatura);
        }
        
    }
    
        public void valorimc(){
        if(IMC <19 ){
            System.out.println("tiene bajo paso, se le recomienda ir al nutricionista");
        }else if(IMC > 25){
            System.out.println("tiene sobre peso, se le recomienta ir al nutricionista"); 
        }else{
            System.out.println("su IMC es normal, se le recomienta seguir así");
        }
    }
   
    
}

//Creación de un Array, lectura de datos con JOptionPane y visualización
import javax.swing.JOptionPane;

public class capturardatosgrafico {
    public static void main(String[] args) {
        int cantidad;
        
        cantidad =Integer.parseInt(JOptionPane.showInputDialog("¿Cuántos números deseas ingresar? "));

        int[] numeros = new int[cantidad];

        for (int i = 0; i < cantidad; i++) {
            numeros[i] =Integer.parseInt(JOptionPane.showInputDialog("Ingrese el valor de la posición " + i));
        }

        System.out.println("");
        
        String ListaNumeros = "";
        for (int i = 0; i < cantidad; i++) {
            ListaNumeros = ListaNumeros + " " + String.valueOf(numeros[i]);
        }
        
        System.out.println("Los números ingresados son: " + ListaNumeros );
    }
}

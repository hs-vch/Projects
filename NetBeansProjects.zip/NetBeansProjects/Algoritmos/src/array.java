
import java.util.Scanner;

public class array {
    public static void main(String[]args){
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("¿Cuantos elementos desea ingresar? ");
        int cantidad = entrada.nextInt();
        
        int[]numeros = new int[cantidad];
        
        for(int i = 0; i < numeros.length; i++){
            System.out.print("Ingrese el valor del elemento en la casilla " + i);
            numeros[i] = entrada.nextInt();
  
           
        }
        
  
    }
    
}

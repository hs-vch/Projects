// Integrantes: Manuel Ricardo Sanchez, Kelly Sofia Rincón Franco

package com.mycompany.parcial1;

import javax.swing.JOptionPane; // Captura de datos y mensajes en la pantalla


public class Parcial1 {
    public static void main(String[] args) {
        //Declaración de variables
        String Opcion = "0";
        String ID = "", Nombre = "", Apellido = "", Direccion = "", Telefono = "", Celular = "", Email = "", Saldo = "", Ciudad = "";
        String ElementoBuscado = "";
        String[] Informacion= new String[0];
        int ElementoEncontrado = 0, NuevoElemento = 0, PosicionElemento = 0;
        
        
        do{
            Opcion = JOptionPane.showInputDialog(null, 
                    "-----------------------menu----------------------\n\n"+
                     "             1. Cargar Array con información \n"+
                     "             2. Modificar elemento\n"+
                     "             3. Eliminar elemento\n"+
                     "             4. Listar elementos\n"+
                     "             5. Buscar elemento\n"+
                     "             6. Salir del programa",
            "Seleccione una opción", JOptionPane.INFORMATION_MESSAGE);
            
            /*Validación de la opción seleccionada
            Switch = Evalua la valiable - opcion - entre parentesis 
            Case = En caso de, compara con la opcion seleccionada por el usuario
            break  = cuando el case se evalua TRUE se debe salir del switch para que no evalue las demas opciones
            default= se usa cuando no se evalua ningun case
            */
            
            switch(Opcion){
                case "1":   
                    
                    // pide cada uno de los datos al usuario para poder acumularlos en el arreglo correspondiente.
                    
                    ID=JOptionPane.showInputDialog(null,"Ingrese el numero de identificación","Identificación",JOptionPane.INFORMATION_MESSAGE);
                    Nombre=JOptionPane.showInputDialog(null,"Ingrese el nombre","nombre",JOptionPane.INFORMATION_MESSAGE);
                    Apellido=JOptionPane.showInputDialog(null,"Ingrese apellidos","Apellidos",JOptionPane.INFORMATION_MESSAGE);
                    Direccion=JOptionPane.showInputDialog(null,"Ingrese la direccion","Direccion",JOptionPane.INFORMATION_MESSAGE);
                    Ciudad=JOptionPane.showInputDialog(null,"Ingrese la ciudad","Ciudad",JOptionPane.INFORMATION_MESSAGE);
                    Telefono=JOptionPane.showInputDialog(null,"Ingrese el numero de Telefono","Telefono",JOptionPane.INFORMATION_MESSAGE);
                    Celular=JOptionPane.showInputDialog(null,"Ingrese el numero de celular","Celular",JOptionPane.INFORMATION_MESSAGE);
                    Email=JOptionPane.showInputDialog(null,"Ingrese el Email","Email",JOptionPane.INFORMATION_MESSAGE);
                    Saldo=JOptionPane.showInputDialog(null,"Ingrese el saldo","saldo",JOptionPane.INFORMATION_MESSAGE);
                    Informacion = new String[9];
                    
                    Informacion[0]=ID;
                    Informacion[1]=Nombre;
                    Informacion[2]=Apellido;
                    Informacion[3]=Direccion;
                    Informacion[4]=Ciudad;
                    Informacion[5]=Telefono;
                    Informacion[6]=Celular;
                    Informacion[7]=Email;
                    Informacion[8]=Saldo;     
                   
                    break;
                    
                case "2":
                    
                    /*El String ElementoBuscado es la variable que se introduce para ingresar el dato a modificar
                    El El equal ignore case es para comparar la información solicitada con la información almacenada en el array
                    
                    */
                    
                    String elementoBuscado = JOptionPane.showInputDialog(
                            null, "Ingrese el dato a modificar (identificación, nombre, apellidos, direccion, ciudad, telefono, celular, email, saldo):",
                            "Modificar Elemento", JOptionPane.INFORMATION_MESSAGE);

   
                       
                        
                         if (elementoBuscado.equalsIgnoreCase("nombre")) {
                            Informacion[1] = JOptionPane.showInputDialog(
                                    null, "Digite el nuevo nombre:", "Modificar nombre",
                                    JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Elemento modificado correctamente.");
                            break;
                        }        
                         
                         if (elementoBuscado.equalsIgnoreCase("apellidos")) {
                            Informacion[2] = JOptionPane.showInputDialog(
                                    null, "Digite los nuevos apellidos:", "Modificar apellidos",
                                    JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Elemento modificado correctamente.");
                            break;
                        }        
                         

                        if (elementoBuscado.equalsIgnoreCase("direccion")) {
                            Informacion[3] = JOptionPane.showInputDialog(
                                    null, "Digite la nueva dirección:", "Modificar Direccion",
                                    JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Elemento modificado correctamente.");
                            break;
                        }
                       
                        if (elementoBuscado.equalsIgnoreCase("ciudad")) {
                            Informacion[4] = JOptionPane.showInputDialog(
                                    null, "Digite la nueva ciudad:", "Modificar ciudad",
                                    JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Elemento modificado correctamente.");
                            break;
                        }
                       
                        if (elementoBuscado.equalsIgnoreCase("telefono")) {
                            Informacion[5] = JOptionPane.showInputDialog(
                                    null, "Digite el nuevo numero de telefono:", "Modificar numero de telefono",
                                    JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Elemento modificado correctamente.");
                            break;
                        }
                       
                        if (elementoBuscado.equalsIgnoreCase("celular")) {
                            Informacion[6] = JOptionPane.showInputDialog(
                                    null, "Digite el nuevo numero de celular:", "Modificar numero de celular",
                                    JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Elemento modificado correctamente.");
                            break;
                        }

                        if (elementoBuscado.equalsIgnoreCase("email")) {
                            Informacion[7] = JOptionPane.showInputDialog(
                                    null, "Digite el nuevo email:", "Modificar Email",
                                    JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Elemento modificado correctamente.");
                            break;
                        }

                        if (elementoBuscado.equalsIgnoreCase("saldo")) {
                            Informacion[8] = JOptionPane.showInputDialog(
                                    null, "Digite el nuevo saldo:", "Modificar saldo",
                                    JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Elemento modificado correctamente.");
                            break;
                        }
                    
                    break;
                    
                case "3":
                    
                    /* A partir de la variable ElementoBuscado, podemos preguntarle al usuario que dato desea eliminar.
                    Ciclo For, sirve para recorrer el arreglo y buscar el elemento que digitalizó el usuario para posteriormente eliminarlo
                    */
                    
                    ElementoEncontrado = 0;
                    NuevoElemento = 0;
                    PosicionElemento = 0;
                    
                    ElementoBuscado = JOptionPane.showInputDialog(null, "¿Que elemento desea eliminar?", "Seleccione un elemento", JOptionPane.INFORMATION_MESSAGE);
                    
                    for(int NroCiclo = 0; NroCiclo < Informacion.length; NroCiclo++){
                        if (Informacion[NroCiclo].equals(ElementoBuscado)){
                            ElementoEncontrado = 1;
                            PosicionElemento = NroCiclo;
                            System.out.print(ElementoEncontrado);
                            JOptionPane.showMessageDialog(null, "Elemento eliminado correctamente.");
                            break;
                        } 
                    }
                    if (ElementoEncontrado ==1){
                        Informacion[PosicionElemento] = "";
                    }else{
                        JOptionPane.showMessageDialog(null, "El elemento a eliminar " + ElementoBuscado + "No está en el arreglo", "Elemento no encontrado", JOptionPane.ERROR_MESSAGE);
                    }
                    break;
                   
                    
                case "4":
                    
                    // el StringBuilder es una forma de concatenar, construir y manipular cadenas de caracteres sin necesidad de usar "+"
                    
                    StringBuilder datosCliente = new StringBuilder();
                    datosCliente.append("Datos del Cliente:\n\n");
                    datosCliente.append("Identificación: ").append(Informacion[0]).append("\n");
                    datosCliente.append("Nombre: ").append(Informacion[1]).append("\n");
                    datosCliente.append("Apellidos: ").append(Informacion[2]).append("\n");
                    datosCliente.append("Dirección: ").append(Informacion[3]).append("\n");
                    datosCliente.append("Ciudad: ").append(Informacion[4]).append("\n");
                    datosCliente.append("Teléfono Fijo: ").append(Informacion[5]).append("\n");
                    datosCliente.append("Teléfono Celular: ").append(Informacion[6]).append("\n");
                    datosCliente.append("Email: ").append(Informacion[7]).append("\n");
                    datosCliente.append("Saldo: ").append(Informacion[8]).append("\n");
   
                    JOptionPane.showMessageDialog(null, datosCliente.toString(), "Datos del Cliente", JOptionPane.INFORMATION_MESSAGE);
                    break;
                    
                case "5":
                    
                    //
                    
                     String datoBuscado = JOptionPane.showInputDialog(null,
                            "Ingrese el dato que desea buscar:", "Buscar Elemento", JOptionPane.INFORMATION_MESSAGE);
                    boolean encontrado = false;

                    for (int i = 0; i < Informacion.length; i++) {
                        if (Informacion[i] != null && Informacion[i].equalsIgnoreCase(datoBuscado)) {
                            JOptionPane.showMessageDialog(null,
                                    "El dato '" + datoBuscado + "' se encuentra en la posición " + i + " del array.",
                                    "Dato Encontrado", JOptionPane.INFORMATION_MESSAGE);
                            encontrado = true;
                            break;
                        }
                    }

                    if (!encontrado) {
                        JOptionPane.showMessageDialog(null,
                                "El dato '" + datoBuscado + "' no se encuentra en el array.", "Dato No Encontrado",
                                JOptionPane.ERROR_MESSAGE);
                    }
                    
                    break;
                    
                case "6":
                    
                    
                    JOptionPane.showMessageDialog(null, "Gracias, hasta pronto!", "Salida del proyecto", JOptionPane.INFORMATION_MESSAGE);
                    Opcion = "6";
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Opción invalida", "Opcion no valida", JOptionPane.ERROR_MESSAGE);
                    
                    }
                               
            }while(Opcion != "6"); //Sale del menú cuando presiona la opción.            
        }
        
 }


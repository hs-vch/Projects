
package proyecto1final;

public class Proyecto1final {


    public static void main(String[] args) {
        
        RegistroNotas curso = new RegistroNotas();
        
        curso.registrarestudiantes();
        curso.registrarmaterias();
        curso.registrarnotas();  
        
        GestorNotas opc = new GestorNotas(curso);
        
        opc.menuprincipal();

    }
    
}

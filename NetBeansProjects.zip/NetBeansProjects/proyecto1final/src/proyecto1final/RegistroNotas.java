
package proyecto1final;

import javax.swing.JOptionPane;


public class RegistroNotas {
    
    String [] estudiantes;
    String [] materias;
    double [][][] notas;

    public RegistroNotas() {
    }

    public String[] getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(String[] estudiantes) {
        this.estudiantes = estudiantes;
    }

    public String[] getMaterias() {
        return materias;
    }

    public void setMaterias(String[] materias) {
        this.materias = materias;
    }

    public double[][][] getNotas() {
        return notas;
    }

    public void setNotas(double[][][] notas) {
        this.notas = notas;
    }
    
    
    
 public void registrarestudiantes(){
         int n_estudiantes = Integer.parseInt(JOptionPane.showInputDialog("Registro del curso\n" +
                                                                                                               "Digite el número de estudiantes a ingresar "));
        estudiantes = new String[n_estudiantes];          
        
         for (int i = 0; i < n_estudiantes; i++){
             estudiantes[i] = JOptionPane.showInputDialog("Ingrese el nombre del estudiante " + (i+1));
         }
 }

 
 public void registrarmaterias(){
         int n_materias = Integer.parseInt(JOptionPane.showInputDialog("Digite el número de materias a ingresar"));
         materias = new String[n_materias];
         
         for(int j = 0; j < n_materias; j++){
         materias[j]=JOptionPane.showInputDialog("Ingrese el nombre de la materia " + (j+1));  
         }
     
 }
        

 public void registrarnotas(){
     
         int n_notas = Integer.parseInt(JOptionPane.showInputDialog("Digite el número de notas a ingresar para cada materia"));
         
         notas = new double[estudiantes.length][materias.length][n_notas];
        
        for (int i = 0; i < materias.length; i++){
            for(int j = 0; j < estudiantes.length; j++){
                for(int q = 0; q<n_notas;q++){
                 notas[j][i][q]= Double.parseDouble(JOptionPane.showInputDialog("Estudiante: " + estudiantes[j] +
                                                                                                                 "\nMateria: " + materias[i] + 
                                                                                                                 "\nIngrese la nota " + (q+1)));  
                }
            }
        }
     
 }
 
public void opciona(){
    
 String mensaje = "";
    
    for (int i = 0; i < estudiantes.length; i++){
        mensaje += "\nEstudiante: " + estudiantes[i];
        for(int j = 0; j < materias.length; j++){
            mensaje+= "\nMateria: " + materias[j];
            mensaje+= "\nNotas: " ;
            for(int q = 0; q<notas[i][j].length;q++){
                mensaje+= notas[i][j][q] + " / ";     
            }
         }
         mensaje+= "\n ";
      }
    
    JOptionPane.showMessageDialog(null, mensaje);
}

public double promedio(double [ ] promediose){
    
    int total = 0;
    
    for(double nota : promediose){
        total += nota;
    }
    return (double) total / promediose.length;
}

public void opcionb(){
    
    String mensaje = "";
    
    double [] promedios = new double[estudiantes.length];
    
    for (int i = 0; i < estudiantes.length; i++) {
        int totalnotasestudiante = 0;
        mensaje += "\nEstudiante: " + estudiantes[i];

        for (int j = 0; j < materias.length; j++) {
            mensaje += "\nMateria: " + materias[j];
            double promedioMateria = promedio(notas[i][j]);
            totalnotasestudiante += promedioMateria;
            mensaje += "\nPromedio en " + materias[j] + ": " + promedioMateria;
        }
        promedios[i] = (double) totalnotasestudiante / materias.length;
        mensaje += "\nPromedio Total: " + promedios[i] + "\n";
         }
     JOptionPane.showMessageDialog(null, mensaje);
  }

public double calcularpromediogeneral(double [ ] promediosg){
    
    double total = 0;
    
    for(double promedio: promediosg){
        total += promedio;
    }
    return (double) total / promediosg.length;
}   

public void opcionc(){
    
    double [] promedios = new double[estudiantes.length];
    
    for (int i = 0; i < estudiantes.length; i++) {
        int totalnotasestudiante = 0;

        for (int j = 0; j < materias.length; j++) {
            double promedioMateria = promedio(notas[i][j]);
            totalnotasestudiante += promedioMateria;
        }
        promedios[i] = (double) totalnotasestudiante / materias.length;
        
    }
    double promedioGeneral = calcularpromediogeneral(promedios);
    JOptionPane.showMessageDialog(null, "Promedio General del curso: " + promedioGeneral);
}

public void opciond(){
    String mensaje = "";
    
    for (int i = 0; i < estudiantes.length; i++) {
        double promedioEstudiante = 0;
        mensaje += "\nEl estudiante " + estudiantes[i];
        
        for (int j = 0; j < materias.length; j++) {
            double promedioMateria = promedio(notas[i][j]);
            promedioEstudiante += promedioMateria;
            
            if(promedioEstudiante >=3){
                mensaje += " - Pasa la asignatura " + materias[j] + " con un promedio de " + promedioMateria;    

            }else{
                mensaje += " - Debe repetir la asignatura " + materias[i]+ " con un promedio de " + promedioMateria;
            }
            mensaje += "\n";
        }     
       
    }
    JOptionPane.showMessageDialog(null, mensaje);
}

public void opcione(){
     
     String mensaje = "Los estudiantes digitados son";
    
    for (int i = 0; i < estudiantes.length; i++){
        mensaje += "\n" + estudiantes[i];
        for(int j = 0; j < materias.length; j++){
            mensaje+= " con " + materias[j] + " en ";
            for(int q = 0; q<notas[i][j].length;q++){
                mensaje+= notas[i][j][q] + " / ";     
            }
            mensaje += "\n";
         }
         mensaje+= "\n";
      }
    
    JOptionPane.showMessageDialog(null, mensaje);
    
}
      
    
}





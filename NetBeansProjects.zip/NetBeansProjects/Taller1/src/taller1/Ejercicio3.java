package taller1;

public class Ejercicio3 {

    private double n_azar;
    private double total_c, total_desc, descuento;
    
    Ejercicio3(double n_azar, double total_c){
        
        this.n_azar = n_azar;
        this.total_c = total_c;       
    }
    
    public String calcular_descuento(){
        
        if(this.n_azar < 74){
            this.descuento = total_c * 0.15;
        }else if(this.n_azar >= 74){
            this.descuento = total_c * 0.20;
        }else{
            this.descuento = 0;
        }    
        
        this.total_desc = this.total_c - this.descuento;
        
        String mensaje = "El total inicial de la compra es $" + this. total_c +
                                    "\n El total con descuento aplicado es $" + this.total_desc +
                                    "\n El dinero descontado es $" + this.descuento;
        
        return mensaje;
    }
    
    
    
}

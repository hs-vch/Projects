package taller1;

public class ejercicio7 {
    private double p_galletas =3500;
    private int galletas = 15, n_galletas;
    
    ejercicio7(int n_galletas){
        
        this.n_galletas = n_galletas;
    }
    
    public String calcularvalor_galletas(){
        
        double v_galleta = this.p_galletas / this.galletas * this.n_galletas;
        
        String mensaje = this.n_galletas + " galletas cuestan $" + v_galleta;
                
         return mensaje;    
    }
    
    
    
}

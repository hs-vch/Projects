
package taller1;

public class ejercicio2 {
    
    String nombre;
    double precio, cantidad, descuento, total;
    
    ejercicio2(String nombre, double precio, double cantidad){
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }
    
    public void calcular_venta(){
        if(this.cantidad > 3){
            this.descuento = (this.precio * this.cantidad ) * 0.2;
        }else{
            this.descuento = (this.precio * this.cantidad )  * 0.1;
        }
        
        this.total = (this.precio * this.cantidad ) - this.descuento;
    }
    
}


package taller1;

public class ejercicio5 {
    
    private int numero_n, numero_p;
    
    ejercicio5(int numero_n){
        
        this.numero_n = numero_n;
    }
    
    public String convertir_numero(){
        
        if(numero_n > 0){
            this.numero_n = this.numero_n * -1;
        }else{
            this.numero_n = this.numero_n *1;
        }
        
        this.numero_p = this.numero_n * -1;
        
        String mensaje = "El numero negativo ingresado es " + this.numero_n +
                        "\n y el numero en positivo " + this.numero_p;
    
    return mensaje;
    
    }
    
}


package taller1;

import javax.swing.JOptionPane;

public class Taller1 {

    public static void main(String[] args) {
        
        String ejer = JOptionPane.showInputDialog("Escriba el número del ejercicio");
        
        switch(ejer){
            case "1":
                
                    /*Hacer un algoritmo que imprima el nombre de un artículo, clave, precio original y
                   su precio con descuento. El descuento lo hace en base a la clave, Si la clave es 01 el
                   descuento es del 10% y si la clave es 02 el descuento en del 20% (sólo existen dos
                    claves).*/
                
                String producto = JOptionPane.showInputDialog("Escriba el nombre del producto");
                String clave = JOptionPane.showInputDialog("Escriba clave: 01 si quiere 10% de descuento, 02 si quiere 20%"
                                                                                      +"de descuento, o presione cualquier tecla si no hay descuento");
                double precio = Double.parseDouble(JOptionPane.showInputDialog("Escriba precio del producto: "));
                
                ejercicio1 obj = new ejercicio1(producto, clave, precio);
                
                String m = obj.calcular_venta();
                JOptionPane.showMessageDialog(null, m);
             break;
             
            case "2":
                
                /*
                    Hacer un algoritmo que calcule el total a pagar por la compra de camisas. Si se
                    compran tres camisas o más se aplica un descuento del 20% sobre el total de la
                    compra y si son menos de tres camisas un descuento del 10%
                */
                
                String pro = JOptionPane.showInputDialog("Escriba nombre del producto");
                double pre = Double.parseDouble(JOptionPane.showInputDialog("Escriba precio del producto"));
                double cantidad = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la cantidad a llevar"));
                
                ejercicio2 obj2 = new ejercicio2(pro, pre, cantidad);
                
                obj2.calcular_venta();
                
                String m2 = "El nombre del producto es: " + obj2.nombre + 
                                    "\n El precio del producto es $" + obj2.precio +
                                    "\n La cantidad a llevar es " + obj2.cantidad + 
                                    "\n El descuento aplicado es $" + obj2.descuento +
                                    "\n El total de la venta es $" + obj2.total;
                                    
                JOptionPane.showMessageDialog(null, m2);
                
             break;
             
            case "3":
                
                /* En un supermercado se hace una promoción, mediante la cual el cliente obtiene un
                descuento dependiendo de un número que se escoge al azar. Si el número escogido
                es menor que 74 el descuento es del 15% sobre el total de la compra, si es mayor o
                igual a 74 el descuento es del 20%. Obtener cuánto dinero se le descuenta.*/
                
                double n_azar =Double.parseDouble(JOptionPane.showInputDialog("Escriba un numero al azar "));
                double total_c =Double.parseDouble(JOptionPane.showInputDialog("Escriba el total de la compra "));
                
                Ejercicio3 obj3 = new Ejercicio3(n_azar, total_c);
                
                
                String m3 = obj3.calcular_descuento();
                
                JOptionPane.showMessageDialog(null, m3);
                        
             break;
             
            case "4":
            break;
            
            case "5":
                /* Elabore un algoritmo que lea un número negativo e imprima el número y el positivo del mismo.*/
                
                int numero_n =Integer.parseInt(JOptionPane.showInputDialog("Escriba un numero negativo "));
                
                ejercicio5 obj5 = new ejercicio5(numero_n);
                
                String m5 = obj5.convertir_numero();
                
                JOptionPane.showMessageDialog(null, m5);
         
            break;
            
            case "6":
                
                /*Hacer un algoritmo que permita pasa de kilogramos a gramos y toneladas.*/
                
                int n_kilogramos = Integer.parseInt(JOptionPane.showInputDialog("Escriba el numero de kilogramos a convertir "));
                String valor_m = JOptionPane.showInputDialog("Digite 'gramos' si desea convertir los kilogramos a gramos, o 'toneladas' si desea convertir los kilogramos a toneladas ");
                
                ejercicio6 obj6 = new ejercicio6(n_kilogramos, valor_m);
                
                obj6.convertir();
                
                String m6 = obj6.n_kilogramos + "kg a " + obj6.valor_m + " es igual a " + obj6.resultado;
                
                JOptionPane.showMessageDialog(null, m6);  
                
            break;
            
            case "7":
               
               /*Un paquete de galletas cuesta $3.500 y contiene 15 galletas, cuánto cuestan 4 de ellas? Elabore un algoritmo para obtener la respuesta.*/
                
                int n_galletas = Integer.parseInt(JOptionPane.showInputDialog("Escriba el numero de galletas"));
                
                ejercicio7 obj7 = new ejercicio7(n_galletas);
                
                String m7 = obj7.calcularvalor_galletas();
                
                JOptionPane.showMessageDialog(null, m7);
                
            break;            
            case "8":
            break;       
            case "9":
            break;       
            case "10":
            break;                   
        }

    }
    
}

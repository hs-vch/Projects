
package taller1;

public class ejercicio6 {
    
    String valor_m;
    int n_kilogramos, resultado;
    
    ejercicio6(int n_kilogramos, String valor_m){
        
        this.n_kilogramos = n_kilogramos;
        this.valor_m = valor_m;
    }
    
    public void convertir(){
        switch(this.valor_m){
            case "gramos": 
                this.resultado = n_kilogramos * 1000;
            break;
            case"toneladas":
                this.resultado = n_kilogramos / 1000;
            break;
            default:
                this.resultado = n_kilogramos;
            break;
        }
        
    }
    
}

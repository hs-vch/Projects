
package taller1;

public class ejercicio1 {
    
    private String nombre, clave;
    private double precio, descuento, total;
    
    ejercicio1(String nombre, String clave, double precio){
        this.nombre = nombre;
        this.clave = clave;
        this.precio = precio;
    }
    
    public String calcular_venta(){
        switch (this.clave){
            case "01":
                this.descuento = this.precio * 0.1;
            break;
            case "02":
                this.descuento = this.precio * 0.2;
            break;
            default:
                this.descuento = 0;
            break;             
        }
        
        this.total = this.precio - this.descuento;
        
        String mensaje = "El nombre del producto es: " + this.nombre +
                                    "\n El precio del producto es $" + this. precio +
                                    "\n El descuento aplicado es $" + this.descuento +
                                    "\n El total de la venta es $" + this.total; 
        
        return mensaje;
    }
    
}

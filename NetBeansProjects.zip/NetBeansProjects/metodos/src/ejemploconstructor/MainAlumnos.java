
package ejemploconstructor;


public class MainAlumnos {
    
      public static void main(String[] args) {
          
          Alumnos alu1 = new Alumnos(12345, "sandra", "caidedo");
          Alumnos alu2 = new Alumnos(67892, "pedro", "ruiz");
          Alumnos alu3 = new Alumnos(11112, "javier", "loaiza");
          
          alu1.verDatos();
          alu2.verDatos();
          alu3.verDatos();
 
    }
    
}


package ejemploconstructor;

//import javax.swing.JOptionPane;

public class MainTriangulo {
    
    public static void main(String [] args){
        
        Triangulo T1 = new Triangulo();
        
        //int Alt = Integer.parseInt(JOptionPane.showInputDialog("Digite la altura del triangulo: "));
        //int Bas = Integer.parseInt(JOptionPane.showInputDialog("Digite la base del triangulo: "));
        
        //T1.setAltura(Alt);
        //T1.setBase(Bas);
        
        T1.setBase(8);
        T1.setAltura(9);
        
        
        System.out.println("La base es: " + T1.getBase());
        System.out.println("La altura es: " + T1.getAltura());
        System.out.println("El area del triangulo es: " + T1.area(T1.getBase(), T1.getAltura()));
    }
    
}

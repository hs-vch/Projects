
package ejemploconstructor;


public class Alumnos {
    
    int noControl;
    String nombre, apellidos;
    
    Alumnos(int nC, String nom, String ape){
        this.noControl = nC;
        this.nombre = nom;
        this.apellidos = ape;
    }
    
    public void verDatos(){
        System.out.println("No. Control: " + noControl);
        System.out.println("Nombre: " + nombre);
        System.out.println("Apellidos: " + apellidos);
        
    }
    
}

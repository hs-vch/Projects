
package proyecto1final;

import javax.swing.JOptionPane;


public class GestorNotas {
    
    public RegistroNotas registroNotas;

    public GestorNotas(RegistroNotas registroNotas) {
        this.registroNotas = registroNotas;
    }
    
     public void menuprincipal(){
         
         String opcion;
         
         do {
             opcion = JOptionPane.showInputDialog("Bienvenido al menú principal del libro de notas\n\n" +
                                                        "Digite alguna de las siguientes opciones \n\n" +
                                                        "a. El nombre del estudiante con sus correspondientes notas y materias\n" +
                                                        "b. El promedio de cada estudiante por materia\n" +
                                                        "c. El promedio del grupo en general \n" +
                                                        "d. Que estudiantes pasan o debe repetir la asignatura\n" +
                                                        "e. Mostrar los datos digitados\n" +
                                                        "f. Organizar notas de mayor a menor\n" +
                                                        "g. cerrar o salir del programa");
             
             switch(opcion){
            case "a":
                registroNotas.opciona();
                break;
            
            case "b":
                registroNotas.opcionb();
                break;
            
            case "c":
                registroNotas.opcionc();
                break;
                
            case "d":
                registroNotas.opciond();
                break;
                
            case "e":
                registroNotas.opcione();
                break;
                
            case "f":
                registroNotas.opcionf();
                break;
                
            case "g":
                JOptionPane.showMessageDialog(null, "Cerrando sesión.");
                
                return; 
                
            default:
                JOptionPane.showMessageDialog(null, "Opción inválida. Por favor, seleccione una opción válida.");
                    }
             
             }while(!opcion.equals("g"));
              
    }
    
}

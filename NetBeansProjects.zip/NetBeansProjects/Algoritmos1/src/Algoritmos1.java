
import java.util.Scanner;

public class Algoritmos1 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("¿Cuántos números deseas ingresar? ");
        int cantidad = entrada.nextInt();

        int[] numeros = new int[cantidad];

        for (int i = 0; i < cantidad; i++) {
            System.out.print("Ingresa el número " + (i + 1) + ": ");
            numeros[i] = entrada.nextInt();
        }

        System.out.println("");
        
        String ListaNumeros = "";
        for (int i = 0; i < cantidad; i++) {
            ListaNumeros = ListaNumeros + " " + String.valueOf(numeros[i]);
        }
        
        System.out.println("Los números ingresados son: " + ListaNumeros );
    }
}

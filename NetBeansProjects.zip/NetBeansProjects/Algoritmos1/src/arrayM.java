//Creación de un Array multidimencional, lectura de datos y visualización
import java.util.Scanner;

public class arrayM {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("¿Cuántas Columnas deseas ingresar? ");
        int cantidadCols = entrada.nextInt();
        
        System.out.print("¿Cuántas Filas deseas ingresar? ");
        int cantidadRows = entrada.nextInt();

        int[][] numeros = new int[cantidadRows][cantidadCols];
        int Rows, Cols = 0;
        
        for (Rows = 0; Rows < numeros.length; Rows++) {
            for (Cols = 0; Cols < numeros[Rows].length; Cols++){
                System.out.print("Ingresa el número para la Fila " + (Rows + 1) + " Columna : " + (Cols + 1) + ": " );
                numeros[Rows][Cols] = entrada.nextInt();
            }
        }

        System.out.println("");
        
        System.out.print("Los valores del Array son");

        for (Rows = 0; Rows < numeros.length; Rows++) {
            for (Cols = 0; Cols < numeros[Rows].length; Cols++){
                System.out.println(numeros[Rows][Cols]);
            }    
        }
    }
}

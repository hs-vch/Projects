/*Creación de un Array con valores aleatorios, lectura de datos 
y visualización*/
import java.util.Scanner;

public class Array1 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int cantidad = 0;
        
        do {
            System.out.print("¿Cuántos números deseas Generar? ");
            cantidad = entrada.nextInt();

            if (cantidad <= 0) {
                System.out.println("Cantidad de Elementos no Válido.");
            }
        } while (cantidad < 1);


        int[] numeros = new int[cantidad];

        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = (int) (Math.random() * 1000) + 1; 
        }
        
        Listar(numeros,cantidad);

    }        
    public static void Listar(int numeros[], int cantidad){
        System.out.println("");
        
        String ListaNumeros = "";
        for (int i = 0; i < cantidad; i++) {
            ListaNumeros = ListaNumeros + " " + String.valueOf(numeros[i]);
        }

        System.out.println("Los números ingresados son: " + ListaNumeros );
        System.out.println("");
   }
}

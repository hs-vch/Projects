//Creación de un Array, lectura de datos y visualización
import java.util.Scanner;

public class arrayDoW {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int cantidad = 0;
        
        do {
            System.out.print("¿Cuántos números deseas Generar? ");
            cantidad = entrada.nextInt();

            if (cantidad <= 0) {
                System.out.println("Cantidad de Elementos no Válido.");
            }
        } while (cantidad < 1);


        int[] numeros = new int[cantidad];

        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = (int) (Math.random() * 1000) + 1; 
        }
        
        Listar(numeros);
        BuscarElemento(numeros);

    }        
    public static void Listar(int numeros[]){
        System.out.println("");
        
        String ListaNumeros = "";
        for (int i = 0; i < numeros.length; i++) {
            ListaNumeros = ListaNumeros + " " + String.valueOf(numeros[i]);
        }

        System.out.println("Los números ingresados son: " + ListaNumeros );
        System.out.println("");
   }
    
   public static void BuscarElemento(int numeros[]){
        System.out.println("");

        Scanner entradaElemento = new Scanner(System.in);

        System.out.print("Digite el valor del elemento a Buscar: ");
        int elementoBuscado = entradaElemento.nextInt();
        
        int PosicionElementoArray = 0; 
        int elementoEncontrado    = 0;
        int NroCiclo              = 0;
        
        do{
            if (numeros[NroCiclo] == elementoBuscado){
                elementoEncontrado = 1;
                PosicionElementoArray = NroCiclo;
            }
            
            NroCiclo++;
            if (NroCiclo > numeros.length){
                break;
            }
        } while(elementoEncontrado == 0);
        
        if (elementoEncontrado == 1){
            System.out.println("El elemento a buscar " + String.valueOf(elementoBuscado) + " está en el Array en la posicion " + String.valueOf(PosicionElementoArray));
        }else{
            System.out.println("El elemento a buscar " + String.valueOf(elementoBuscado) + " NO está en el Array");
        }
        System.out.println("");
   }
}
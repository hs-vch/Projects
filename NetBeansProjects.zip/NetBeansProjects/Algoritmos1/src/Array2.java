//Creación de un Array, lectura de datos y visualización
import java.util.Scanner;

public class Array2 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int cantidad = 0;
        
        do {
            System.out.print("¿Cuántos números deseas ingresar? ");
            cantidad = entrada.nextInt();

            if (cantidad <= 0) {
                System.out.println("Cantidad de Elementos no Válido.");
            }
        } while (cantidad < 1);


        int[] numeros = new int[cantidad];

        for (int i = 0; i < cantidad; i++) {
            System.out.print("Ingresa el número " + (i + 1) + ": ");
            numeros[i] = entrada.nextInt();
        }
        
        Listar(numeros,cantidad);

    }        
    public static void Listar(int numeros[], int cantidad){
        System.out.println("");
        
        String ListaNumeros = "";
        for (int i = 0; i < cantidad; i++) {
            ListaNumeros = ListaNumeros + " " + String.valueOf(numeros[i]);
        }

        System.out.println("Los números ingresados son: " + ListaNumeros );
        System.out.println("");
     }
}